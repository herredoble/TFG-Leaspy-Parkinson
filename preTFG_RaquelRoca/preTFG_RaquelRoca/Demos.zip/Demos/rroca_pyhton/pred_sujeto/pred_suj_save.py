# -*- coding: utf-8 -*-
"""
Created on Wed Dec 13 23:10:38 2023

@author: rroca
"""


# Determinar las trayectorias de un nuevo paciente un año antes y cinco años después 
# de la última visita a partir de un modelo construido. Cada marcador debe estar en su 
# escala natural. Se mostrará los datos clínicos adquiridos y las trayectorias 
# estimadas. La variable independiente es la edad del sujeto.


#############################################
#PRIMER CODIGO
#############################################

import os
from scipy import stats
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style('whitegrid')
pd.options.display.float_format = '{:.4g}'.format
# import main classes from Leaspy package
from leaspy import Leaspy, Data, AlgorithmSettings, IndividualParameters, __watermark__
from leaspy.io.logs.visualization.plotting import Plotting
data_path = lambda *p: os.path.join('./data', *p)
# Watermark trace with all packages versions
__watermark__


percent_SDMT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_SDMT.npy')
point_feat_SDMT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_SDMT.npy')
percent_LNS=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_LNS.npy')
point_feat_LNS=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_LNS.npy')
percent_HVLTRDLY=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_HVLTRDLY.npy')
point_feat_HVLTRDLY=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_HVLTRDLY.npy')
percent_SFT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_SFT.npy')
point_feat_SFT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_SFT.npy')
percent_MEANCAU=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_MEANCAU.npy')
point_feat_MEANCAU=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_MEANCAU.npy')
percent_ABETA=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_ABETA.npy')
point_feat_ABETA=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_ABETA.npy')

datai = pd.read_csv(data_path('dataiTP2.csv'))

#PARTE1: DATA
df = pd.DataFrame({
    'ID': datai['PATNO'].astype(str),
    'TIME': datai['TIME'],
    'SDMT': datai['SDMT_norm'],
    'LNS': datai['LNS_n'],
    'HVLTRDLY':datai['HVLTRDLY_n'],
    'SFT': datai['SFT_n'],
    'MEANCAU':datai['MEANCAU_n'],
    'ABETA': datai['ABETA_n']        
})
  
df_orig = pd.DataFrame({
    'ID': datai['PATNO'].astype(str),
    'TIME': datai['TIME'],
    'SDMT': datai['SDMTOTAL'],
    'LNS': datai['lns'],
    'HVLTRDLY':datai['HVLTRDLY'],
    'SFT': datai['sft'],
    'MEANCAU':datai['mean_caudate'],
    'ABETA': datai['abeta']        
})
    
df = df.set_index(["ID","TIME"], verify_integrity=True).sort_index()

n_subjects = df.index.get_level_values('ID').unique().shape[0]
print(f'{n_subjects} subjects in the dataset.')

df_train = df.iloc[:705, :]
df_test = df.iloc[706:, :]
print(df_train)
print(df_test)

x=input("Introduce el ID del sujeto (3777-4136): ")

while True:
    try:
        x = input("Introduce el ID del sujeto (3777-4136): ")
        x = str(x)
        
        if x in df_test.index.get_level_values('ID').unique():
            print(f"ID {x} encontrado en df_Test.")
            break  # Salir del bucle si el ID es válido
        else:
            print(f"ID {x} no encontrado en df_Test. Introduce otro ID.")
    except ValueError:
        print("Error: Introduce un ID válido.")

df_orig['DX'] = np.where(datai['cogstate'] > 1, 'MCI', 'CN').astype(str)
df_pred_orig=df_orig[df_orig['ID']==x]

df_pred=df_test[df_test.index.get_level_values('ID')==x]
visita_inicial=df_pred.index.get_level_values('TIME').min()
visita_final=df_pred.index.get_level_values('TIME').max()
año_min_det=visita_inicial-1
año_max_det=visita_final +5

leaspy = Leaspy("logistic",
                source_dimension=2,             # number of dimensions for non-temporal inter-subject variability
                noise_model='gaussian_diagonal' # estimate the residual noise scaling per feature
         )
leaspy_plotting = Plotting(leaspy.model)

algo_settings = AlgorithmSettings('mcmc_saem',
                                  n_iter=3000,           # n_iter defines the number of iterations
                                  seed=0)  

algo_settings.set_logs(
    path='./logs',          # Creates a logs file ; if existing, ask if rewrite it
    plot_periodicity=50,  # Saves the values to display in pdf every 50 iterations
    save_periodicity=10,  # Saves the values in csv files every 10 iterations
    console_print_periodicity=None,  # If = N, it display logs in the console/terminal every N iterations
    overwrite_logs_folder=True       # Default behaviour raise an error if the folder already exists.
)

"""
ID_train=df_train.index.get_level_values('ID').unique()
sample_size=len(ID_train) // 10
btps=10
bootstraps=[]
for i in range(btps):
    sampled_ids = np.random.choice(ID_train, sample_size, replace=False)
    sampled_dataframe = df_train.loc[sampled_ids]
    sampled_dataframe.sort_index(level='ID', inplace=True)
    bootstraps.append(sampled_dataframe)
    """   
data_train = Data.from_dataframe(df_train)
data_test = Data.from_dataframe(df_test)

###############
# CALIBRATION --> Obtencion parametros y trayectoria grupal media
leaspy.fit(data_train, settings=algo_settings)
  
leaspy.model.parameters

noise = leaspy.model.parameters['noise_std']
features = leaspy.model.features
  
print('Standard deviation of the residual noise for the feature:')
for n, f in zip(noise, features):
    print(f'- {f}: {n*100:.2f}%')
    
if not os.path.exists("outputs/"):
   os.makedirs("outputs/")
  
leaspy.save("outputs/model_parameters.json")
leaspy = Leaspy.load('outputs/model_parameters.json')      
  
#################
# PERSONALISATION
settings_personalization = AlgorithmSettings('scipy_minimize', seed=0)
ip = leaspy.personalize(data_test, settings_personalization)    

######################################
#RECONTRUCTION, IMPUTATION, PREDICTION (CON VALORES NORMALIZADOS)
observations = df_pred.reset_index().copy()
observations.drop('ID', axis=1, inplace=True)
observations.set_index('TIME', inplace=True)

print(f'Seen ages: {observations.index.values}')
print("Individual Parameters : ", ip[x])

timepoints = np.linspace(año_min_det, año_max_det, 100)
reconstruction_norm = leaspy.estimate({x: timepoints}, ip)

col = ["SDMT", "LNS", "HVLTRDLY", "SFT", "MEANCAU", "ABETA"]
df_rec_sujnorm=[]
for i in range(100):
    d3 = {k: v[i] for k, v in reconstruction_norm.items()}
    dw = pd.DataFrame.from_dict(d3, orient='index', columns = [s+"_model1" for s in col])
    df_rec_sujnorm.append(dw)
df_rec_sujnorm = pd.concat(df_rec_sujnorm, axis=0).reset_index(drop=True)


def plot_trajectory(timepoints, reconstruction, observations=None):

    if observations is not None:
        ages = observations.index.values

    plt.figure(figsize=(14, 6))
    plt.ylim(0, 1)
    plt.ylabel('Biomarker normalized value')
    plt.xlim(año_min_det-10, año_max_det +10)
    plt.xlabel('Patient age')
    colors = ['#ef5675', '#577590', '#48a07e', '#f4d35e', '#7a5195', '#f4874b']
    #rojo,azul,verde, amarillo, violeta, naranja
    for i, (c, name, val) in enumerate(zip(colors, leaspy.model.features, reconstruction.T)):
        plt.subplot(2, 3, i+1)  # Ajusta el número de filas y columnas según tus necesidades
        plt.plot(timepoints, val, label=name, c=c, linewidth=3)
        if observations is not None:
            plt.plot(ages, observations[name], c=c, marker='o', markersize=12)
        plt.legend()
        
    plt.tight_layout()
    plt.show()

plot_trajectory(timepoints, reconstruction_norm[x], observations)


#######################################
#RECONTRUCTION, IMPUTATION, PREDICTION (CON VALORES ORIGINALES)

def inverse_percentil_interp(normalized_values, point_feat, percent):
    data = pd.DataFrame({'point_feat': point_feat, 'percent': percent})
    data = data.sort_values(by='percent')
    original_values = np.interp(normalized_values, data['percent'], data['point_feat'])
    return original_values

v_percent=[percent_SDMT,percent_LNS,percent_HVLTRDLY,percent_SFT,percent_MEANCAU,percent_ABETA]
v_feat=[point_feat_SDMT,point_feat_LNS,point_feat_HVLTRDLY,point_feat_SFT,point_feat_MEANCAU,point_feat_ABETA]
var_rec_suj=['SDMT_model1','LNS_model1','HVLTRDLY_model1','SFT_model1','MEANCAU_model1','ABETA_model1',]
df_rec_sujorig=pd.DataFrame()

for i, v in enumerate(var_rec_suj):
    df_rec_sujorig[v]=inverse_percentil_interp(df_rec_sujnorm.loc[:,v],v_feat[i],v_percent[i])
    df_rec_sujorig[v]=-df_rec_sujorig[v]

reconstruction_orig = {
        x: df_rec_sujorig.values
}

observations_orig = df_pred_orig.reset_index(drop=True).copy()
observations_orig.drop('ID', axis=1, inplace=True)
observations_orig.set_index('TIME', inplace=True)

plot_trajectory(timepoints, reconstruction_orig[x], observations_orig)



#############################################
#SEGUNDO CODIGO
#############################################


# Determinar las trayectorias de un nuevo paciente un año antes y cinco años después 
# de la última visita a partir de un modelo construido. Cada marcador debe estar en su 
# escala natural. Se mostrará los datos clínicos adquiridos y las trayectorias 
# estimadas. La variable independiente es la edad del sujeto.


import os
from scipy import stats
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style('whitegrid')
pd.options.display.float_format = '{:.4g}'.format
# import main classes from Leaspy package
from leaspy import Leaspy, Data, AlgorithmSettings, IndividualParameters, __watermark__
from leaspy.io.logs.visualization.plotting import Plotting
data_path = lambda *p: os.path.join('./data', *p)
# Watermark trace with all packages versions
__watermark__


percent_SDMT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_SDMT.npy')
point_feat_SDMT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_SDMT.npy')
percent_LNS=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_LNS.npy')
point_feat_LNS=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_LNS.npy')
percent_HVLTRDLY=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_HVLTRDLY.npy')
point_feat_HVLTRDLY=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_HVLTRDLY.npy')
percent_SFT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_SFT.npy')
point_feat_SFT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_SFT.npy')
percent_MEANCAU=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_MEANCAU.npy')
point_feat_MEANCAU=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_MEANCAU.npy')
percent_ABETA=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_ABETA.npy')
point_feat_ABETA=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_ABETA.npy')

datai = pd.read_csv(data_path('dataiTP2.csv'))

#PARTE1: DATA
df = pd.DataFrame({
    'ID': datai['PATNO'].astype(str),
    'TIME': datai['TIME'],
    'SDMT': datai['SDMT_norm'],
    'LNS': datai['LNS_n'],
    'HVLTRDLY':datai['HVLTRDLY_n'],
    'SFT': datai['SFT_n'],
    'MEANCAU':datai['MEANCAU_n'],
    'ABETA': datai['ABETA_n']        
})
  
df_orig = pd.DataFrame({
    'ID': datai['PATNO'].astype(str),
    'TIME': datai['TIME'],
    'SDMT': datai['SDMTOTAL'],
    'LNS': datai['lns'],
    'HVLTRDLY':datai['HVLTRDLY'],
    'SFT': datai['sft'],
    'MEANCAU':datai['mean_caudate'],
    'ABETA': datai['abeta']        
})
    
df = df.set_index(["ID","TIME"], verify_integrity=True).sort_index()

n_subjects = df.index.get_level_values('ID').unique().shape[0]
print(f'{n_subjects} subjects in the dataset.')

df_train = df.iloc[:705, :]
df_test = df.iloc[706:, :]
print(df_train)
print(df_test)

x=input("Introduce el ID del sujeto (3777-4136): ")

while True:
    try:
        x = input("Introduce el ID del sujeto (3777-4136): ")
        x = str(x)
        
        if x in df_test.index.get_level_values('ID').unique():
            print(f"ID {x} encontrado en df_Test.")
            break  # Salir del bucle si el ID es válido
        else:
            print(f"ID {x} no encontrado en df_Test. Introduce otro ID.")
    except ValueError:
        print("Error: Introduce un ID válido.")

df_orig['DX'] = np.where(datai['cogstate'] > 1, 'MCI', 'CN').astype(str)
df_pred_orig=df_orig[df_orig['ID']==x]

df_pred=df_test[df_test.index.get_level_values('ID')==x]
visita_inicial=df_pred.index.get_level_values('TIME').min()
visita_final=df_pred.index.get_level_values('TIME').max()
año_min_det=visita_inicial-1
año_max_det=visita_final +5

leaspy = Leaspy("logistic",
                source_dimension=2,             # number of dimensions for non-temporal inter-subject variability
                noise_model='gaussian_diagonal' # estimate the residual noise scaling per feature
         )
leaspy_plotting = Plotting(leaspy.model)

algo_settings = AlgorithmSettings('mcmc_saem',
                                  n_iter=3000,           # n_iter defines the number of iterations
                                  seed=0)  

algo_settings.set_logs(
    path='./logs',          # Creates a logs file ; if existing, ask if rewrite it
    plot_periodicity=50,  # Saves the values to display in pdf every 50 iterations
    save_periodicity=10,  # Saves the values in csv files every 10 iterations
    console_print_periodicity=None,  # If = N, it display logs in the console/terminal every N iterations
    overwrite_logs_folder=True       # Default behaviour raise an error if the folder already exists.
)

ID_train=df_train.index.get_level_values('ID').unique()
sample_size=len(ID_train) // 10
btps=10
bootstraps=[]
for i in range(btps):
    sampled_ids = np.random.choice(ID_train, sample_size, replace=False)
    sampled_dataframe = df_train.loc[sampled_ids]
    sampled_dataframe.sort_index(level='ID', inplace=True)
    bootstraps.append(sampled_dataframe)
    
    
    
def inverse_percentil_interp(normalized_values, point_feat, percent):
    data = pd.DataFrame({'point_feat': point_feat, 'percent': percent})
    data = data.sort_values(by='percent')
    original_values = np.interp(normalized_values, data['percent'], data['point_feat'])
    return original_values

def plot_trajectory(timepoints, reconstruction, observations=None):

    if observations is not None:
        ages = observations.index.values

    plt.figure(figsize=(14, 6))
    plt.ylim(0, 1)
    plt.ylabel('Biomarker normalized value')
    plt.xlim(año_min_det-10, año_max_det +10)
    plt.xlabel('Patient age')
    colors = ['#ef5675', '#577590', '#48a07e', '#f4d35e', '#7a5195', '#f4874b']
    #rojo,azul,verde, amarillo, violeta, naranja
    for i, (c, name, val) in enumerate(zip(colors, leaspy.model.features, reconstruction.T)):
        plt.subplot(2, 3, i+1)  # Ajusta el número de filas y columnas según tus necesidades
        plt.plot(timepoints, val, label=name, c=c, linewidth=3)
        if observations is not None:
            plt.plot(ages, observations[name], c=c, marker='o', markersize=12)
        plt.legend()
        
    plt.tight_layout()
    plt.show()

#i=0   si
#i=1   si
#i=2   si
#i=3   si
#i=4
#i=5
#i=6
#i=7
#i=8
#i=9


reconstruciones_norm=[]
reconstruciones_orig=[]

for i in range(btps):
    data_train = Data.from_dataframe(bootstraps[i])
    data_test = Data.from_dataframe(df_test)

    ###############
    # CALIBRATION --> Obtencion parametros y trayectoria grupal media
    leaspy.fit(data_train, settings=algo_settings)
      
    leaspy.model.parameters
    
    noise = leaspy.model.parameters['noise_std']
    features = leaspy.model.features
      
    print('Standard deviation of the residual noise for the feature:')
    for n, f in zip(noise, features):
        print(f'- {f}: {n*100:.2f}%')
        
    if not os.path.exists("outputs/"):
       os.makedirs("outputs/")
    
       
    #guardar cada bootsrap con nombre distinto.COmo? te ahorras tener que hacer este proceso todo el rato
    #leaspy.save("outputs/model_parameters.json")
    #leaspy = Leaspy.load('outputs/model_parameters.json')   
    
    # Guardar el modelo en un archivo .json con nombre "model_i.json"
    model_filename = f"model_parameters{i}.json"
    model_path = os.path.join("outputs/", model_filename)

    leaspy.save(model_path)
    leaspy=leaspy.load(model_path)
    
    #################
    # PERSONALISATION
    settings_personalization = AlgorithmSettings('scipy_minimize', seed=0)
    ip = leaspy.personalize(data_test, settings_personalization)

    ######################################
    #RECONTRUCTION, IMPUTATION, PREDICTION (CON VALORES NORMALIZADOS)
    observations = df_pred.reset_index().copy()
    observations.drop('ID', axis=1, inplace=True)
    observations.set_index('TIME', inplace=True)

    print(f'Seen ages: {observations.index.values}')
    print("Individual Parameters : ", ip[x])

    timepoints = np.linspace(año_min_det, año_max_det, 100)
    reconstruction_norm = leaspy.estimate({x: timepoints}, ip)

    col = ["SDMT", "LNS", "HVLTRDLY", "SFT", "MEANCAU", "ABETA"]
    df_rec_sujnorm=[]

    for j in range(100):
        d3 = {k: v[j] for k, v in reconstruction_norm.items()}
        i=str(i)
        dw = pd.DataFrame.from_dict(d3, orient='index', columns = [s+"_model_"+i for s in col])
        df_rec_sujnorm.append(dw)
    df_rec_sujnorm = pd.concat(df_rec_sujnorm, axis=0).reset_index(drop=True)
    reconstruciones_norm.append(df_rec_sujnorm)
    #df_final = pd.concat(dataframes_list, ignore_index=True)
    
    plot_trajectory(timepoints, reconstruction_norm[x], observations)
    
    #######################################
    #RECONTRUCTION, IMPUTATION, PREDICTION (CON VALORES ORIGINALES)
    v_percent=[percent_SDMT,percent_LNS,percent_HVLTRDLY,percent_SFT,percent_MEANCAU,percent_ABETA]
    v_feat=[point_feat_SDMT,point_feat_LNS,point_feat_HVLTRDLY,point_feat_SFT,point_feat_MEANCAU,point_feat_ABETA]
    var_rec_suj=['SDMT_model_'+i,'LNS_model_'+i,'HVLTRDLY_model_'+i,'SFT_model_'+i,'MEANCAU_model_'+i,'ABETA_model_'+i,]
    df_rec_sujorig=pd.DataFrame()

    for k, v in enumerate(var_rec_suj):
        df_rec_sujorig[v]=inverse_percentil_interp(df_rec_sujnorm.loc[:,v],v_feat[k],v_percent[k])
        df_rec_sujorig[v]=-df_rec_sujorig[v]
    reconstruciones_orig.append(df_rec_sujorig)
    
    
    reconstruction_orig = {
            x: df_rec_sujorig.values
    }

    observations_orig = df_pred_orig.reset_index(drop=True).copy()
    observations_orig.drop('ID', axis=1, inplace=True)
    observations_orig.set_index('TIME', inplace=True)

    plot_trajectory(timepoints, reconstruction_orig[x], observations_orig)


#MAE:
# - Seleccionar para cada bootstrap las reconstrucciones en los tiempos de las 
#   observaciones. Es decir, tenemos seis variables, y diez reconstrucciones de 
#   esas variables (1 por bootstrap). Si tenemos cuatro observaciones en 4 tiempos
#   distintos, tendremos un dataframe 6 variables x 10 reconstrucciones (60 columnas) 
#   y cuatro filas correspondientes a las filas de los tiempos iguales a los de 
#   observaciones.

def calculate_mae(samples, estimate):
    print(samples)
    print(estimate)
    bstrp = estimate.shape[1]
    mae_feat=[]
    for r in range(bstrp):        
        resta=np.array(samples.iloc[:,0].values-estimate.iloc[:,r].values)
        absoluto=np.abs(resta)
        media=np.mean(absoluto)
        #mae_feat[r]=np.mean(np.abs(estimate.iloc[:,r].values-samples.values))
        mae_feat.append(media)

        print(mae_feat[r])
    
    return mae_feat

df_reconstruciones_norm = pd.concat(reconstruciones_norm, axis=1)
df_reconstruciones_orig = pd.concat(reconstruciones_orig, axis=1)
TIME_obs=observations.index.get_level_values('TIME')
indices_cercanos = [np.argmin(np.abs(timepoints - numero)) for numero in TIME_obs]
df_estimations_norm=df_reconstruciones_norm.iloc[indices_cercanos]
df_estimations_orig=df_reconstruciones_orig.iloc[indices_cercanos]

mae_list=[]

for i, a in enumerate(features):
    samples_n=observations[a].reset_index(drop=True).to_frame()
    samples_o=observations_orig[a].reset_index(drop=True).to_frame()
    
    feat_estim_n = df_estimations_norm.filter(like=a).reset_index(drop=True)
    feat_estim_o = df_estimations_orig.filter(like=a).reset_index(drop=True)
    
    mae_list.append(calculate_mae(samples_o, feat_estim_o))

mae_list_transposed = list(map(list, zip(*mae_list)))
MAE = pd.DataFrame(mae_list_transposed, columns=features)



#DX (CN, MCI, pCU):
# - Ver el estado cognitivo del paciente en las observaciones(visitas) que tiene,
#   si cambia de CN a MCI entre la primera y la ultima visita ver en que tiempo se 
#   producira el cambio y representarlo como una linea vertical en la grafica



#############################################
#TERCER CODIGO (10 modelos y con NAN)
#############################################

# Determinar las trayectorias de un nuevo paciente un año antes y cinco años después 
# de la última visita a partir de un modelo construido. Cada marcador debe estar en su 
# escala natural. Se mostrará los datos clínicos adquiridos y las trayectorias 
# estimadas. La variable independiente es la edad del sujeto.


import os
from scipy import stats
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style('whitegrid')
pd.options.display.float_format = '{:.4g}'.format
# import main classes from Leaspy package
from leaspy import Leaspy, Data, AlgorithmSettings, IndividualParameters, __watermark__
from leaspy.io.logs.visualization.plotting import Plotting
data_path = lambda *p: os.path.join('./data', *p)
# Watermark trace with all packages versions
__watermark__


percent_SDMT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_SDMT.npy')
point_feat_SDMT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_SDMT.npy')
percent_LNS=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_LNS.npy')
point_feat_LNS=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_LNS.npy')
percent_HVLTRDLY=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_HVLTRDLY.npy')
point_feat_HVLTRDLY=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_HVLTRDLY.npy')
percent_SFT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_SFT.npy')
point_feat_SFT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_SFT.npy')
percent_MEANCAU=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_MEANCAU.npy')
point_feat_MEANCAU=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_MEANCAU.npy')
percent_ABETA=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_ABETA.npy')
point_feat_ABETA=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_ABETA.npy')

datai = pd.read_csv(data_path('dataiTP2.csv'))

#PARTE1: DATA
df = pd.DataFrame({
    'ID': datai['PATNO'].astype(str),
    'TIME': datai['TIME'],
    'ABETA': datai['ABETA_n'],
    'HVLTRDLY':datai['HVLTRDLY_n'],
    'LNS': datai['LNS_n'],
    'MEANCAU':datai['MEANCAU_n'],
    'SDMT': datai['SDMT_n'],
    'SFT': datai['SFT_n']
})
  
df_orig = pd.DataFrame({
    'ID': datai['PATNO'].astype(str),
    'TIME': datai['TIME'],
    'ABETA': datai['abeta'], 
    'HVLTRDLY':datai['HVLTRDLY'],
    'LNS': datai['lns'],
    'MEANCAU':datai['mean_caudate'],
    'SDMT': datai['SDMTOTAL'],
    'SFT': datai['sft']           
})
    
df = df.set_index(["ID","TIME"], verify_integrity=True).sort_index()

n_subjects = df.index.get_level_values('ID').unique().shape[0]
print(f'{n_subjects} subjects in the dataset.')

df_train = df.iloc[:705, :]
df_test = df.iloc[706:, :]
print(df_train)
print(df_test)

while True:
    try:
        x = input("Introduce el ID del sujeto (3777-4136): ")
        x = str(x)
        
        if x in df_test.index.get_level_values('ID').unique():
            print(f"ID {x} encontrado en df_Test.")
            break  # Salir del bucle si el ID es válido
        else:
            print(f"ID {x} no encontrado en df_Test. Introduce otro ID.")
    except ValueError:
        print("Error: Introduce un ID válido.")

df_orig['DX'] = np.where(datai['cogstate'] > 1, 'MCI', 'CN').astype(str)
df_pred_orig=df_orig[df_orig['ID']==x]

df_pred=df_test[df_test.index.get_level_values('ID')==x]
visita_inicial=df_pred.index.get_level_values('TIME').min()
visita_final=df_pred.index.get_level_values('TIME').max()
año_min_det=visita_inicial-1
año_max_det=visita_final +5

leaspy = Leaspy("logistic",
                source_dimension=2,             # number of dimensions for non-temporal inter-subject variability
                noise_model='gaussian_diagonal' # estimate the residual noise scaling per feature
         )
leaspy_plotting = Plotting(leaspy.model)

algo_settings = AlgorithmSettings('mcmc_saem',
                                  n_iter=3000,           # n_iter defines the number of iterations
                                  seed=0)  

algo_settings.set_logs(
    path='./logs',          # Creates a logs file ; if existing, ask if rewrite it
    plot_periodicity=50,  # Saves the values to display in pdf every 50 iterations
    save_periodicity=10,  # Saves the values in csv files every 10 iterations
    console_print_periodicity=None,  # If = N, it display logs in the console/terminal every N iterations
    overwrite_logs_folder=True       # Default behaviour raise an error if the folder already exists.
)

ID_train=df_train.index.get_level_values('ID').unique()
sample_size=len(ID_train) // 10
btps=10
bootstraps=[]
for i in range(btps):
    sampled_ids = np.random.choice(ID_train, sample_size, replace=False)
    sampled_dataframe = df_train.loc[sampled_ids]
    sampled_dataframe.sort_index(level='ID', inplace=True)
    bootstraps.append(sampled_dataframe)
    
    
    
def inverse_percentil_interp(normalized_values, point_feat, percent):
    data = pd.DataFrame({'point_feat': point_feat, 'percent': percent})
    data = data.sort_values(by='percent')
    original_values = np.interp(normalized_values, data['percent'], data['point_feat'])
    return original_values

def plot_trajectory(timepoints, reconstruction, observations=None):

    if observations is not None:
        ages = observations.index.values

    plt.figure(figsize=(14, 6))
    plt.ylim(0, 1)
    plt.ylabel('Biomarker normalized value')
    plt.xlim(año_min_det-10, año_max_det +10)
    plt.xlabel('Patient age')
    colors = ['#ef5675', '#577590', '#48a07e', '#f4d35e', '#7a5195', '#f4874b']
    #rojo,azul,verde, amarillo, violeta, naranja
    for i, (c, name, val) in enumerate(zip(colors, leaspy.model.features, reconstruction.T)):
        plt.subplot(2, 3, i+1)  # Ajusta el número de filas y columnas según tus necesidades
        plt.plot(timepoints, val, label=name, c=c, linewidth=3)
        if observations is not None:
            plt.plot(ages, observations[name], c=c, marker='o', markersize=12)
        plt.legend()
        
    plt.tight_layout()
    plt.show()

#i=0   si
#i=1   si
#i=2   si
#i=3   si
#i=4
#i=5
#i=6
#i=7
#i=8
#i=9


reconstruciones_norm=[]
reconstruciones_orig=[]

for i in range(btps):
    data_train = Data.from_dataframe(bootstraps[i])
    data_test = Data.from_dataframe(df_test)

    ###############
    # CALIBRATION --> Obtencion parametros y trayectoria grupal media
    leaspy.fit(data_train, settings=algo_settings)
      
    leaspy.model.parameters
    
    noise = leaspy.model.parameters['noise_std']
    features = leaspy.model.features
      
    print('Standard deviation of the residual noise for the feature:')
    for n, f in zip(noise, features):
        print(f'- {f}: {n*100:.2f}%')
        
    if not os.path.exists("outputs/"):
       os.makedirs("outputs/")
    
       
    #guardar cada bootsrap con nombre distinto.COmo? te ahorras tener que hacer este proceso todo el rato
    #leaspy.save("outputs/model_parameters.json")
    #leaspy = Leaspy.load('outputs/model_parameters.json')   
    
    # Guardar el modelo en un archivo .json con nombre "model_i.json"
    model_filename = f"model_parameters{i}.json"
    model_path = os.path.join("outputs/", model_filename)

    leaspy.save(model_path)
    leaspy=leaspy.load(model_path)
    
    #################
    # PERSONALISATION
    settings_personalization = AlgorithmSettings('scipy_minimize', seed=0)
    ip = leaspy.personalize(data_test, settings_personalization)

    ######################################
    #RECONTRUCTION, IMPUTATION, PREDICTION (CON VALORES NORMALIZADOS)
    observations = df_pred.reset_index().copy()
    observations.drop('ID', axis=1, inplace=True)
    observations.set_index('TIME', inplace=True)

    print(f'Seen ages: {observations.index.values}')
    print("Individual Parameters : ", ip[x])

    timepoints = np.linspace(año_min_det, año_max_det, 100)
    reconstruction_norm = leaspy.estimate({x: timepoints}, ip)

    col = ["ABETA", "HVLTRDLY", "LNS", "MEANCAU", "SDMT",  "SFT"]
    df_rec_sujnorm=[]

    for j in range(100):
        d3 = {k: v[j] for k, v in reconstruction_norm.items()}
        i=str(i)
        dw = pd.DataFrame.from_dict(d3, orient='index', columns = [s+"_model_"+i for s in col])
        df_rec_sujnorm.append(dw)
    df_rec_sujnorm = pd.concat(df_rec_sujnorm, axis=0).reset_index(drop=True)
    reconstruciones_norm.append(df_rec_sujnorm)
    #df_final = pd.concat(dataframes_list, ignore_index=True)
    
    plot_trajectory(timepoints, reconstruction_norm[x], observations)
    
    #######################################
    #RECONTRUCTION, IMPUTATION, PREDICTION (CON VALORES ORIGINALES)
    v_percent=[percent_ABETA,percent_HVLTRDLY,percent_LNS,percent_MEANCAU,percent_SDMT,percent_SFT]
    v_feat=[point_feat_ABETA,point_feat_HVLTRDLY,point_feat_LNS,point_feat_MEANCAU,point_feat_SDMT,point_feat_SFT]
    var_rec_suj=['ABETA_model_'+i,'HVLTRDLY_model_'+i,'LNS_model_'+i,'MEANCAU_model_'+i,'SDMT_model_'+i,'SFT_model_'+i]
    df_rec_sujorig=pd.DataFrame()

    for k, v in enumerate(var_rec_suj):
        df_rec_sujorig[v]=inverse_percentil_interp(df_rec_sujnorm.loc[:,v],v_feat[k],v_percent[k])
        df_rec_sujorig[v]=-df_rec_sujorig[v]
    reconstruciones_orig.append(df_rec_sujorig)
    
    
    reconstruction_orig = {
            x: df_rec_sujorig.values
    }

    observations_orig = df_pred_orig.reset_index(drop=True).copy()
    observations_orig.drop('ID', axis=1, inplace=True)
    observations_orig.set_index('TIME', inplace=True)

    plot_trajectory(timepoints, reconstruction_orig[x], observations_orig)


#MAE:
# - Seleccionar para cada bootstrap las reconstrucciones en los tiempos de las 
#   observaciones. Es decir, tenemos seis variables, y diez reconstrucciones de 
#   esas variables (1 por bootstrap). Si tenemos cuatro observaciones en 4 tiempos
#   distintos, tendremos un dataframe 6 variables x 10 reconstrucciones (60 columnas) 
#   y cuatro filas correspondientes a las filas de los tiempos iguales a los de 
#   observaciones.

def calculate_mae(samples, estimate):
    print(samples)
    print(estimate)
    bstrp = estimate.shape[1]
    mae_feat=[]
    
    filas_con_nan = samples[samples.isna().any(axis=1)].index

    samples = samples.drop(index=filas_con_nan)
    estimate = estimate.drop(index=filas_con_nan)
    for r in range(bstrp):        
        resta=np.array(samples.iloc[:,0].values-estimate.iloc[:,r].values)
        absoluto=np.abs(resta)
        media=np.mean(absoluto)
        #mae_feat[r]=np.mean(np.abs(estimate.iloc[:,r].values-samples.values))
        mae_feat.append(media)

        print(mae_feat[r])
    
    return mae_feat

df_reconstruciones_norm = pd.concat(reconstruciones_norm, axis=1)
df_reconstruciones_orig = pd.concat(reconstruciones_orig, axis=1)
TIME_obs=observations.index.get_level_values('TIME')
indices_cercanos = [np.argmin(np.abs(timepoints - numero)) for numero in TIME_obs]
df_estimations_norm=df_reconstruciones_norm.iloc[indices_cercanos]
df_estimations_orig=df_reconstruciones_orig.iloc[indices_cercanos]

mae_list=[]

for i, a in enumerate(features):
    samples_n=observations[a].reset_index(drop=True).to_frame()
    samples_o=observations_orig[a].reset_index(drop=True).to_frame()
    
    feat_estim_n = df_estimations_norm.filter(like=a).reset_index(drop=True)
    feat_estim_o = df_estimations_orig.filter(like=a).reset_index(drop=True)
    
    mae_list.append(calculate_mae(samples_o, feat_estim_o))

mae_list_transposed = list(map(list, zip(*mae_list)))
MAE = pd.DataFrame(mae_list_transposed, columns=features)



#DX (CN, MCI, pCU):
# - Ver el estado cognitivo del paciente en las observaciones(visitas) que tiene,
#   si cambia de CN a MCI entre la primera y la ultima visita ver en que tiempo se 
#   producira el cambio y representarlo como una linea vertical en la grafica



#############################################
#ULTIMO CODIGO 
#############################################
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 27 17:20:52 2023

@author: rroca
"""

# Determinar las trayectorias de un nuevo paciente un año antes y cinco años después 
# de la última visita a partir de un modelo construido. Cada marcador debe estar en su 
# escala natural. Se mostrará los datos clínicos adquiridos y las trayectorias 
# estimadas. La variable independiente es la edad del sujeto.


import os
from scipy import stats
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style('whitegrid')
pd.options.display.float_format = '{:.4g}'.format
# import main classes from Leaspy package
from leaspy import Leaspy, Data, AlgorithmSettings, IndividualParameters, __watermark__
from leaspy.io.logs.visualization.plotting import Plotting
data_path = lambda *p: os.path.join('./data', *p)
# Watermark trace with all packages versions
__watermark__


percent_SDMT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_SDMT.npy')
point_feat_SDMT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_SDMT.npy')
percent_LNS=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_LNS.npy')
point_feat_LNS=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_LNS.npy')
percent_HVLTRDLY=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_HVLTRDLY.npy')
point_feat_HVLTRDLY=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_HVLTRDLY.npy')
percent_SFT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_SFT.npy')
point_feat_SFT=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_SFT.npy')
percent_MEANCAU=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_MEANCAU.npy')
point_feat_MEANCAU=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_MEANCAU.npy')
percent_ABETA=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/percent_ABETA.npy')
point_feat_ABETA=np.load('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/pred_sujeto/data/percents_and_pfeat/pfeat_ABETA.npy')

datai = pd.read_csv(data_path('dataiTP2.csv'))
datai['DX'] = np.where(datai['cogstate'] > 1, 'MCI', 'CN').astype(str)

#PARTE1: DATA
df = pd.DataFrame({
    'ID': datai['PATNO'].astype(str),
    'TIME': datai['TIME'],
    #'DX':datai['DX'],
    'ABETA': datai['ABETA_n'],
    'HVLTRDLY':datai['HVLTRDLY_n'],
    'LNS': datai['LNS_n'],
    'MEANCAU':datai['MEANCAU_n'],
    'SDMT': datai['SDMT_n'],
    'SFT': datai['SFT_n']
})
  
df_orig = pd.DataFrame({
    'ID': datai['PATNO'].astype(str),
    'TIME': datai['TIME'],
    #'DX':datai['DX'],
    'ABETA': datai['abeta'], 
    'HVLTRDLY':datai['HVLTRDLY'],
    'LNS': datai['lns'],
    'MEANCAU':datai['mean_caudate'],
    'SDMT': datai['SDMTOTAL'],
    'SFT': datai['sft']           
})
    
df = df.set_index(["ID","TIME"], verify_integrity=True).sort_index()

n_subjects = df.index.get_level_values('ID').unique().shape[0]
print(f'{n_subjects} subjects in the dataset.')
idx_subjects=df.index.get_level_values('ID').unique()

#DIVISION TRAIN-TEST
from sklearn.model_selection import train_test_split

# Dividir el índice en conjuntos de entrenamiento y prueba
idx_subjects_train, idx_subjects_test = train_test_split(idx_subjects, test_size=0.2, random_state=42)
idx_subjects_train = np.sort(idx_subjects_train)
idx_subjects_test = np.sort(idx_subjects_test)

df_train = df.loc[idx_subjects_train]
df_test = df.loc[idx_subjects_test]
"""
idx_subjects_train_bst, idx_subjects_val = train_test_split(idx_subjects_train, test_size=0.2, random_state=42)
idx_subjects_train_bst = np.sort(idx_subjects_train_bst)
idx_subjects_val = np.sort(idx_subjects_val)

df_train_bst = df.loc[idx_subjects_train_bst]
df_val = df.loc[idx_subjects_val]
"""
n = input("Introduce un numero entre 1 y 423: ")
n=int(n)
x = idx_subjects.get_level_values('ID')[n-1]

df_pred_orig=df_orig[df_orig['ID']==x]
df_pred=df[df.index.get_level_values('ID')==x]
visita_inicial=df_pred.index.get_level_values('TIME').min()
visita_final=df_pred.index.get_level_values('TIME').max()
año_min_det=visita_inicial-1
año_max_det=visita_final +5

leaspy = Leaspy("logistic",
                source_dimension=2,             # number of dimensions for non-temporal inter-subject variability
                noise_model='gaussian_diagonal' # estimate the residual noise scaling per feature
         )
leaspy_plotting = Plotting(leaspy.model, output_path='./plotLeaspyModel')

algo_settings = AlgorithmSettings('mcmc_saem',
                                  n_iter=20,#3000           # n_iter defines the number of iterations
                                  seed=0)  

algo_settings.set_logs(
    path='./logs',          # Creates a logs file ; if existing, ask if rewrite it
    plot_periodicity=20,  # Saves the values to display in pdf every 50 iterations
    save_periodicity=10,  # Saves the values in csv files every 10 iterations
    console_print_periodicity=False,  # If = N, it display logs in the console/terminal every N iterations
    overwrite_logs_folder=True       # Default behaviour raise an error if the folder already exists.
)



#SE HACE UN DF_VAL PARA CADA BOOSTRAP???????

ID_train=df_train.index.get_level_values('ID').unique()
#sample_size=len(ID_train) // 10
sample_size=int(len(ID_train)*0.8)
btps=10
bootstraps=[]
for i in range(btps):
    sampled_ids = np.random.choice(ID_train, sample_size, replace=False)
    sampled_dataframe = df_train.loc[sampled_ids]
    sampled_dataframe.sort_index(level='ID', inplace=True)
    bootstraps.append(sampled_dataframe)
    
    
 
def inverse_percentil_interp(normalized_values, point_feat, percent):
    data = pd.DataFrame({'point_feat': point_feat, 'percent': percent})
    data = data.sort_values(by='percent')
    original_values = np.interp(normalized_values, data['percent'], data['point_feat'])
    return original_values

def plot_trajectory(timepoints, reconstruction, observations=None, i=None, j=None):

    if observations is not None:
        ages = observations.index.values

    plt.figure(figsize=(14, 6))
    if (j==0):
        title = f'Progresión Variables Normalizadas (Modelo {i})' if i is not None else 'Progresión Variables Normalizadas'
        plt.suptitle(title, fontsize=16)  # Añadir título
    elif (j==1):
        title = f'Progresión Variables Originales (Modelo {i})' if i is not None else 'Progresión Variables Originales'
        plt.suptitle(title, fontsize=16)  # Añadir título
    plt.ylim(0, 1)
    plt.ylabel('Biomarker normalized value')
    plt.xlim(año_min_det-10, año_max_det +10)
    plt.xlabel('Patient age')
    colors = ['#ef5675', '#577590', '#48a07e', '#f4d35e', '#7a5195', '#f4874b']
    #rojo,azul,verde, amarillo, violeta, naranja
    for i, (c, name, val) in enumerate(zip(colors, leaspy.model.features, reconstruction.T)):
        plt.subplot(2, 3, i+1)  # Ajusta el número de filas y columnas según tus necesidades
        plt.plot(timepoints, val, label=name, c=c, linewidth=3)
        if observations is not None:
            plt.plot(ages, observations[name], c=c, marker='o', markersize=12)
        plt.legend()
        
    plt.tight_layout()
    
    # Guardar la gráfica en el directorio especificado
    save_path='./plots/norm_orig'
    if save_path:
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        filename = f"trajectory_plot_model_{i}.png" if i is not None else "trajectory_plot.png"
        filepath = os.path.join(save_path, filename)
        plt.savefig(filepath)
        plt.close()  # Cerrar la figura después de guardarla
    else:
        plt.show()

#i=0   si, si
#i=1   si, si
#i=2   si, si
#i=3   si, si
#i=4   si, si
#i=5   si, si
#i=6   si, si
#i=7   si, si
#i=8   si, si
#i=9   no, si

reconstruciones_norm=[]
reconstruciones_orig=[]
data_test = Data.from_dataframe(df_test)
data_df = Data.from_dataframe(df)
parameters = {'betas': [], 'g': [], 'noise_std': [], 'sources_mean': [], 'sources_std': [], 'tau_mean': [], 'tau_std': [], 'v0': [], 'xi_mean': [], 'xi_std': []}

for i in range(btps):
    data_train = Data.from_dataframe(bootstraps[i])

    ###############
    # CALIBRATION --> Obtencion parametros y trayectoria grupal media
    leaspy.fit(data_train, settings=algo_settings)
      
    leaspy.model.parameters
    parameters['betas'].append(leaspy.model.parameters['betas'].numpy())
    parameters['g'].append(leaspy.model.parameters['g'].numpy())
    parameters['noise_std'].append(leaspy.model.parameters['noise_std'].numpy())
    parameters['sources_mean'].append(leaspy.model.parameters['sources_mean'].numpy())
    parameters['sources_std'].append(leaspy.model.parameters['sources_std'].numpy())
    parameters['tau_mean'].append(leaspy.model.parameters['tau_mean'].numpy())
    parameters['tau_std'].append(leaspy.model.parameters['tau_std'].numpy())
    parameters['v0'].append(leaspy.model.parameters['v0'].numpy())
    parameters['xi_mean'].append(leaspy.model.parameters['xi_mean'].numpy())
    parameters['xi_std'].append(leaspy.model.parameters['xi_std'].numpy())
    features = leaspy.model.features
    noise=leaspy.model.parameters['noise_std']
    
    print('Standard deviation of the residual noise for the feature:')
    for n, f in zip(noise, features):
        print(f'- {f}: {n*100:.2f}%')
        
    if not os.path.exists("outputs/"):
       os.makedirs("outputs/")
    
    #guardar cada bootsrap con nombre distinto.COmo? te ahorras tener que hacer este proceso todo el rato
    #leaspy.save("outputs/model_parameters.json")
    #leaspy = Leaspy.load('outputs/model_parameters.json')   
    
    # Guardar el modelo en un archivo .json con nombre "model_i.json"
    model_filename = f"model_parameters{i}.json"
    model_path = os.path.join("outputs/", model_filename)

    leaspy.save(model_path)
    
#AQUI  
TAU=[]

for i in range(btps):
    model_filename = f"model_parameters{i}.json"
    model_path = os.path.join("outputs/", model_filename)
    leaspy=leaspy.load(model_path)
    
    #################
    # PERSONALISATION
    
    settings_personalization = AlgorithmSettings('scipy_minimize', seed=0)
    ip = leaspy.personalize(data_df, settings_personalization)

    ######################################
    #RECONTRUCTION, IMPUTATION, PREDICTION (CON VALORES NORMALIZADOS)
    observations = df_pred.reset_index().copy()
    observations.drop('ID', axis=1, inplace=True)
    observations.set_index('TIME', inplace=True)

    print(f'Seen ages: {observations.index.values}')
    print("Individual Parameters : ", ip[x])
    TAU.append(ip[x])

    timepoints = np.linspace(año_min_det, año_max_det, 100)
    reconstruction_norm = leaspy.estimate({x: timepoints}, ip)

    col = ["ABETA", "HVLTRDLY", "LNS", "MEANCAU", "SDMT",  "SFT"]
    df_rec_sujnorm=[]

    for j in range(100):
        d3 = {k: v[j] for k, v in reconstruction_norm.items()}
        i=str(i)
        dw = pd.DataFrame.from_dict(d3, orient='index', columns = [s+"_model_"+i for s in col])
        df_rec_sujnorm.append(dw)
    df_rec_sujnorm = pd.concat(df_rec_sujnorm, axis=0).reset_index(drop=True)
    reconstruciones_norm.append(df_rec_sujnorm)
    #df_final = pd.concat(dataframes_list, ignore_index=True)
    
    plot_trajectory(timepoints, reconstruction_norm[x], observations, i, j=0)
    
    #######################################
    #RECONTRUCTION, IMPUTATION, PREDICTION (CON VALORES ORIGINALES)
    v_percent=[percent_ABETA,percent_HVLTRDLY,percent_LNS,percent_MEANCAU,percent_SDMT,percent_SFT]
    v_feat=[point_feat_ABETA,point_feat_HVLTRDLY,point_feat_LNS,point_feat_MEANCAU,point_feat_SDMT,point_feat_SFT]
    var_rec_suj=['ABETA_model_'+i,'HVLTRDLY_model_'+i,'LNS_model_'+i,'MEANCAU_model_'+i,'SDMT_model_'+i,'SFT_model_'+i]
    df_rec_sujorig=pd.DataFrame()

    for k, v in enumerate(var_rec_suj):
        df_rec_sujorig[v]=inverse_percentil_interp(df_rec_sujnorm.loc[:,v],v_feat[k],v_percent[k])
        df_rec_sujorig[v]=-df_rec_sujorig[v]
    reconstruciones_orig.append(df_rec_sujorig)
    
    reconstruction_orig = {
            x: df_rec_sujorig.values
    }

    observations_orig = df_pred_orig.reset_index(drop=True).copy()
    observations_orig.drop('ID', axis=1, inplace=True)
    observations_orig.set_index('TIME', inplace=True)

    plot_trajectory(timepoints, reconstruction_orig[x], observations_orig, i, j=1)

TAU_df=pd.DataFrame(TAU)
TAU_df=TAU_df[['tau']]


#MAE:
# - Seleccionar para cada bootstrap las reconstrucciones en los tiempos de las 
#   observaciones. Es decir, tenemos seis variables, y diez reconstrucciones de 
#   esas variables (1 por bootstrap). Si tenemos cuatro observaciones en 4 tiempos
#   distintos, tendremos un dataframe 6 variables x 10 reconstrucciones (60 columnas) 
#   y cuatro filas correspondientes a las filas de los tiempos iguales a los de 
#   observaciones.

# MAE= Para cada modelo, es la media de la diferencias entre las estimaciones y las muestras en
#      cada tiempo muestreado. por lo que tendremos una tabla de 6x10, cada variable tiene un MAE 
#      modelo(bstrp)

def calculate_mae(samples, estimate):
    print(samples)
    print(estimate)
    bstrp = estimate.shape[1]
    mae_feat=[]
    filas_con_nan = samples[samples.isna().any(axis=1)].index

    samples = samples.drop(index=filas_con_nan)
    estimate = estimate.drop(index=filas_con_nan)
    for r in range(bstrp):        
        resta=np.array(samples.iloc[:,0].values-estimate.iloc[:,r].values)
        absoluto=np.abs(resta)
        media=np.mean(absoluto)
        #mae_feat[r]=np.mean(np.abs(estimate.iloc[:,r].values-samples.values))
        mae_feat.append(media)
        print(mae_feat[r])

    return mae_feat

df_reconstruciones_norm = pd.concat(reconstruciones_norm, axis=1)
df_reconstruciones_orig = pd.concat(reconstruciones_orig, axis=1)
TIME_obs=observations.index.get_level_values('TIME')
indices_cercanos = [np.argmin(np.abs(timepoints - numero)) for numero in TIME_obs]
df_estimations_norm=df_reconstruciones_norm.iloc[indices_cercanos]
df_estimations_orig=df_reconstruciones_orig.iloc[indices_cercanos]

mae_list=[]

for i, a in enumerate(features):
    samples_n=observations[a].reset_index(drop=True).to_frame()
    samples_o=observations_orig[a].reset_index(drop=True).to_frame()
    
    feat_estim_n = df_estimations_norm.filter(like=a).reset_index(drop=True)
    feat_estim_o = df_estimations_orig.filter(like=a).reset_index(drop=True)
    
    mae_list.append(calculate_mae(samples_o, feat_estim_o))
    

mae_list_transposed = list(map(list, zip(*mae_list)))
MAE = pd.DataFrame(mae_list_transposed, columns=features)
medias = MAE.mean()
MAE=MAE.append(medias, ignore_index=True)
MAE=MAE.rename(index={len(MAE)-1:'Media'})
"""
CALCULAR NMAE
"""    


#DX (CN, MCI, pCU):
# - Ver el estado cognitivo del paciente en las observaciones(visitas) que tiene,
#   si cambia de CN a MCI entre la primera y la ultima visita ver en que tiempo se 
#   producira el cambio y representarlo como una linea vertical en la grafica (INDICADO POR TAU).
#   datai.DX guarda el estado cognitivo de cada paciente en cada visita

# 1. diiagnose
grouped = datai.groupby('PATNO')
patient_states = grouped['DX'].apply(list)
labels = pd.DataFrame(patient_states.tolist(), index=patient_states.index)
ultima_visita_index = labels.apply(lambda row: row.last_valid_index(), axis=1)
estado_ultima_visita = labels.lookup(labels.index, ultima_visita_index)
diagnose=pd.DataFrame({'lbl_init':labels.iloc[:,0],'lbl_end':estado_ultima_visita})

# 2. quitar MCI first y CN last
