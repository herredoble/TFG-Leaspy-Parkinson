# -*- coding: utf-8 -*-
"""
Created on Sat Feb 17 18:27:38 2024

@author: rroca
"""

"""
EL TP1 trabaja con tabla general y crea parametros de normalizacion
y tabla base para el TP2. Para ello usa las funciones en pre_funciones
el cual usa funciones en pre_funciones2

El TP2 trabaja a partir de la tabla guardada en TP1(df_PD2) como 
data_inicio_tp2 la cual se va a pasar igual a nuestro programa como 
dataiTP2 y se crean los df_train y los df_Test y el df guardados como df_trainTP2, 
df_testTp2 y dfTP2.
"""

import os
from scipy import stats
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style('whitegrid')
pd.options.display.float_format = '{:.4g}'.format
# import main classes from Leaspy package
from leaspy import Leaspy, Data, AlgorithmSettings, IndividualParameters, __watermark__
from leaspy.io.logs.visualization.plotting import Plotting
from itertools import combinations
data_path = lambda *p: os.path.join('./data', *p)
# Watermark trace with all packages versions
__watermark__

from funciones.getdataPPMI import getdataPPMI
from funciones.prep_data import prep_data
from funciones.build_Leaspy import build_Leaspy

"""
Cuando funcione todo bien tengo que normalizar todas las variables porque se va
a trabajar con todas (esto en getdataPPMI o dividir esta funcion en get data y 
luego normalizar)
"""

datai, features_norm, features_orig, features_name=getdataPPMI()
datai['PATNO']=datai['PATNO'].astype(str)
datai['DX'] = np.where(datai['cogstate'] > 1, 'MCI', 'CN').astype(str)
classes = ['CN', 'MCI']

#feature_names_norm=['SDMT_n','LNS_n','HVLTRDLY_n','SFT_n','MEANCAU_n','ABETA_n']
#features_names_orig=['SDMTOTAL','lns','HVLTRDLY','sft','mean_caudate','abeta']
#features=['SDMT','LNS','HVLTRDLY','SFT','MEANCAU','ABETA']

"""
% Markers:
%     1. MOCA(-)
%     2. GDS (+)
%     3. UPSIT (-)
%     4. REM (+)
%     5. LNS (-)
%     6. SDMT (-)
%     7. JLO (-)       <--NO ESTÁ
%     8. INMEDIATE (-) <--NO ESTÁ
%     9. HVLTRDLY (-) (ES 7-1)
%     10. SFT (-)     (ES 8-1)
%     11. ADL (-)     <--NO ESTÁ
%     12. SCOPA (+)   (ES 9-1)
%     13. MEANPUT (-) (ES 10-1)
%     14. MEANCAU (-) (ES 11-1)
%     15. ABETA (-)   (ES 12-1)
%     16. ASYN (-)    (ES 13-1)
%     17. TAU (+)     ...
%     18. PTAU (+)    <--NO ESTÁ
%     19. pTauAB (+)  (ES 15-1)
%     20. UPDRSTOT    ...
%     21. UPDRSTOTON
%     22. UPDRS1
%     23. UPDRS2 
%     24. UPDRS3 (+)
%     25. UPDRS3ON     ...""" 

inic_vars=['PATNO','TIME','DX']
#features_set = [15,9,5,14,6,10]
#vector_range=range(3,6)
features_set=[1,2,5,7]   #SERÍA [1,2,5,9]
vector_range=range(4,5)
head_fich_name ="C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/outputs/data_multi/Leaspy_vars_"
logs_fich_name="C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/logs/Leaspy_vars_"
btstrp=10

featNorm = [features_norm[i-1] for i in features_set]
featOrig = [features_orig[i-1] for i in features_set]
featNames = [features_name[i-1] for i in features_set]

selected_columns_norm=inic_vars+featNorm
selected_columns_orig=inic_vars+featOrig
df=datai.loc[:,selected_columns_norm]
df_orig=datai.loc[:,selected_columns_orig]

df, df_orig, diagnose, labels, idx_subjects_train, idx_subjects_test=prep_data(df, df_orig, classes, featNorm, featOrig, featNames)
df_reset=df.reset_index()
ages=df_reset.groupby('ID')['TIME'].apply(list).reset_index()
ages = pd.DataFrame(ages)
ages=ages.set_index('ID')

# POOL MARKER SETS
features_set_i=features_set
features_set = range(0, len(features_set))
max_dim = vector_range[-1]
features_subset_matrix = np.full((10000, max_dim), np.nan)
next_row = 0
for i in vector_range:
    aux_subsets = combinations(features_set, i)
    aux_subsets = np.array([list(subset) for subset in aux_subsets])
    n_rows = aux_subsets.shape[0]
    features_subset_matrix[next_row:next_row+n_rows, :i] = aux_subsets
    next_row += n_rows

features_subset_matrix = features_subset_matrix[:next_row, :]
# GUARDAR EN UNA CARPETA LOS INDICES QUE SON Y LUEGO DE 1 A RANGE VECTOR PARA CADA 
# GRUPO.

# READ MODELS
#Lo tegno hecho en otra funcion
"""
alreadyBuiltModels=False
if alreadyBuiltModels :
    mask_DPM_built = np.zeros(features_subset_matrix.shape[0], dtype=bool)
    for i in range(features_subset_matrix.shape[0]):
        idx_markers = features_subset_matrix[i]
        idx_markers = idx_markers[~np.isnan(idx_markers)]
        str_feat = '_'.join(map(str, idx_markers))
        fich_name = head_fich_name + str_feat
        
        if os.path.exists(fich_name + '.mat'):
            mask_DPM_built[i] = True
    
    features_subset_matrix = features_subset_matrix[mask_DPM_built, :]
"""

# PRIMERO-> CREAR MODELOS PARA CADA CONJUNTO DE VARS
    #INCIALIZACION VARIBLES
    
    #BUCLE SUBSET A SUBSET
for i in range(features_subset_matrix.shape[0]):
    idx_markers = features_subset_matrix[i]
    idx_markers = idx_markers[~np.isnan(idx_markers)].astype(int)
    
    #model_feat = ', '.join(featNames[int(idx_markers[0])])
    model_feat = ', '.join([featNames[int(idx)] for idx in idx_markers])
    print(f'Model {i+1} of {model_feat}')
    resto_name = [features_set_i[indice] for indice in idx_markers]
    str_feat = '_'.join(map(str, resto_name))
    fich_name = head_fich_name + str_feat
    logs_fich_name= logs_fich_name+str_feat
    
    if not os.path.exists(fich_name + '.mat'):
        
        #df, df_orig, idx_markers, labels, diagnose, classes, idx_subjects_train, idx_subjects_test, btstrp, fich_name, features
        featsN=[featNorm[i] for i in idx_markers]
        df_subset=df[featsN].copy()
        featsO=[featOrig[i] for i in idx_markers]
        df_orig_subset=df_orig[featsO].copy()
        
        MAE, NMAE, AUC, percent_PD_CU, percent_PD_MCI, corr_PD_MCI_age, corr_PD_MCI_reserve = build_Leaspy(df_subset, df_orig_subset, ages, labels, diagnose, classes, 
                             idx_subjects_train, idx_subjects_test, btstrp,
                             fich_name, featsN, logs_fich_name)
    else:
        
        data = np.load(fich_name + '.mat', allow_pickle=True)
        AUC = data['auc']
        percent_PD_CU = [data['m_test'].percentage_PD_CU, data['m_train'].percentage_PD_CU]
        percent_PD_MCI = [data['m_test'].percentage_PD_MCI, data['m_train'].percentage_PD_MCI]
        corr_PD_MCI_age = [data['m_test'].corr_PD_MCI_age, data['m_train'].corr_PD_MCI_age]
        corr_PD_MCI_reserve = [data['m_test'].corr_PD_MCI_reserve, data['m_train'].corr_PD_MCI_reserve]    



    













