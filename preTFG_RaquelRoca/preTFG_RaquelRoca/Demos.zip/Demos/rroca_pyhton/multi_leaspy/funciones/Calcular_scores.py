# -*- coding: utf-8 -*-
"""
Created on Thu Mar  7 12:42:34 2024

@author: rroca
"""
import numpy as np
import pandas as pd
from datetime import datetime
from scipy.interpolate import interp1d
# import main classes from Leaspy package
from leaspy import Leaspy, Data, AlgorithmSettings, IndividualParameters, __watermark__
from leaspy.io.logs.visualization.plotting import Plotting
import os
data_path = lambda *p: os.path.join('./data', *p)

def calcular_SCORE1(sCU, Ageiend, Ageionset):
    """
    PACIENTES CU EN i Y f, EL EVENTO DEBE SUCEDER DESPPUES DE LA UTLIM VISITA
    Calcula el SCORE1 según la fórmula proporcionada.

    Args:
        sCU (int): Número total de sujetos con función cognitiva normal.
        Ageiend (array-like): Edades en la última visita para cada sujeto.
        Ageionset (float): Edad estimada en la que inicia el declive cognitivo.

    Returns:
        float: Puntaje SCORE1.
    """
    cumplen_condicion = sum(Ageiend < Ageionset)
    SCORE1 = cumplen_condicion / sCU if sCU != 0 else 0
    return SCORE1

def calcular_SCORE2(sMCI, Agei1, Ageionset):
    """
    PACIENTES CON MCI EN i Y f, EL EVENTO DEBE SER ANTES O EN LA PRIMERA VISITA
    Calcula el SCORE2 según la fórmula proporcionada.

    Args:
        sMCI (int): Número total de sujetos con deterioro cognitivo leve.
        Agei1 (array-like): Edades en la primera visita para cada sujeto.
        Ageionset (float): Edad estimada en la que inicia el declive cognitivo.

    Returns:
        float: Puntaje SCORE2.
    """
    cumplen_condicion = sum(Agei1 >= Ageionset)
    SCORE2 = cumplen_condicion / sMCI if sMCI != 0 else 0
    return SCORE2

def calcular_SCORE3(sMCI, Agei1, Ageiend, Ageionset, pCU):
    """
    PACIENTES QUE CU EN i Y MCI EN f, CON EL EVENTO MAYOR QUE LA EDAD DE i
    Calcula el SCORE3 según la fórmula proporcionada.

    Args:
        sMCI (int): Número total de sujetos con deterioro cognitivo leve.
        Agei1 (array-like): Edades en la primera visita para cada sujeto.
        Ageionset (float): Edad estimada en la que inicia el declive cognitivo.
        pCU (int): Número total de sujetos con preclínica de la enfermedad de Alzheimer.

    Returns:
        float: Puntaje SCORE3.
    """
    cumplen_condicion = sum((Agei1 < Ageionset))
    SCORE3 = cumplen_condicion / pCU if pCU != 0 else 0
    return SCORE3

def calcular_SCORE4(sMCI, Agei1, Ageiend, Ageionset, pCU):
    """
    PACIENTES QUE CU EN i Y MCI EN f, CON EL EVENTO MENOR O IGUAL QUE LA EDAD f
    Calcula el SCORE4 según la fórmula proporcionada.

    Args:
        sMCI (int): Número total de sujetos con deterioro cognitivo leve.
        Agei1 (array-like): Edades en la primera visita para cada sujeto.
        Ageionset (float): Edad estimada en la que inicia el declive cognitivo.
        pCU (int): Número total de sujetos con preclínica de la enfermedad de Alzheimer.

    Returns:
        float: Puntaje SCORE3.
    """
    cumplen_condicion = sum((Ageiend <= Ageionset))
    SCORE4 = cumplen_condicion / pCU if pCU != 0 else 0
    return SCORE4

def Calcular_scores(df, ages, labels, diagnose, last_visits_dict, first_visits_dict, IPs, idx):
    # Calcular num pacietnes fin CN/MCI
    sCU = (diagnose['lbl_end'] == 'CN').sum()
    sMCI = (diagnose['lbl_end'] == 'MCI').sum()
    pCU = ((diagnose['lbl_init'] == 'CN') & (diagnose['lbl_end'] == 'MCI')).sum()
    
    age_onset_dict = {}
    for x in idx:
        age_onset_dict[x]=IPs._individual_parameters[x]['tau']

    age_onset = pd.DataFrame(list(age_onset_dict.items()), columns=['x', 'tau'])
    age_onset.set_index('x', inplace=True)

    last_visits = pd.DataFrame(list(last_visits_dict.items()), columns=['x', 'last_visits'])
    last_visits.set_index('x', inplace=True)
    
    first_visits = pd.DataFrame(list(first_visits_dict.items()), columns=['x', 'first_visits'])
    first_visits.set_index('x', inplace=True)

    SCORE1=calcular_SCORE1(sCU, last_visits['last_visits'], age_onset['tau'])
    SCORE2=calcular_SCORE2(sMCI, first_visits['first_visits'], age_onset['tau'])
    SCORE3=calcular_SCORE3(sMCI, first_visits['first_visits'],last_visits['last_visits'], age_onset['tau'], pCU)
    SCORE4=calcular_SCORE4(sMCI, first_visits['first_visits'],last_visits['last_visits'], age_onset['tau'], pCU)
    
    return SCORE1, SCORE2, SCORE3, SCORE4