# -*- coding: utf-8 -*-
"""
Created on Tue Feb 20 11:51:19 2024

@author: rroca
"""

"""
CONTRUYE LOS MODELOS PARA EL GRUPO DE VARIABLES QUE SE LE PASA A LA FUNCION
GUARDADOS EN DF_SUBSET
"""
import numpy as np
import pandas as pd
from datetime import datetime
from scipy.interpolate import interp1d
# import main classes from Leaspy package
from leaspy import Leaspy, Data, AlgorithmSettings, IndividualParameters, __watermark__
from leaspy.io.logs.visualization.plotting import Plotting
import os
data_path = lambda *p: os.path.join('./data', *p)

from funciones.build_model_Leaspy import build_model_Leaspy
from funciones.Leaspy_Test_personalization import Leaspy_Test_personalization
from funciones.Calcular_scores import Calcular_scores
def build_Leaspy(df_subset, df_orig_subset, ages, labels, diagnose, classes, idx_subjects_train, idx_subjects_test, btstrp, fich_name, feats, logs_fich_name):
    
    #DATA
    df_train=df_subset.loc[idx_subjects_train]
    ages_train=ages.loc[idx_subjects_train]
    labels_train=labels.loc[idx_subjects_train]
    diagnose_train=diagnose.loc[idx_subjects_train]
    
    df_test=df_subset.loc[idx_subjects_test]
    ages_test=ages.loc[idx_subjects_test]
    labels_test=labels.loc[idx_subjects_test]
    diagnose_test=diagnose.loc[idx_subjects_test]
    
    
    #LEASPY TRAINING
    #OPTIONS
    leaspy = Leaspy("logistic",
                    source_dimension=2,             # number of dimensions for non-temporal inter-subject variability
                    noise_model='gaussian_diagonal' # estimate the residual noise scaling per feature
             )
    leaspy_plotting = Plotting(leaspy.model)

    algo_settings = AlgorithmSettings('mcmc_saem',
                                      n_iter=50,#3000           # n_iter defines the number of iterations
                                      seed=0)  

    algo_settings.set_logs(
        path=logs_fich_name,          # Creates a logs file ; if existing, ask if rewrite it
        plot_periodicity=50,  # Saves the values to display in pdf every 50 iterations
        save_periodicity=10,  # Saves the values in csv files every 10 iterations
        console_print_periodicity=None,  # If = N, it display logs in the console/terminal every N iterations
        overwrite_logs_folder=True       # Default behaviour raise an error if the folder already exists.
    )
    
    #FUNCION BUILD MODEL--> CON TRAIN
    if os.path.exists(fich_name) and os.listdir(fich_name):
        modelo_construido = True
    else:
        modelo_construido = False
  
    if not modelo_construido:
        parameters, leaspy, Idx_train, output_directory = build_model_Leaspy(df_train, ages_train,labels_train, diagnose_train, idx_subjects_train, classes, btstrp,leaspy,leaspy_plotting,algo_settings, fich_name)
    else:
        output_directory = os.path.join("outputs", fich_name)
        if not os.path.exists(output_directory):
           os.makedirs(output_directory) 

    
    #LEASPY TESTING --> MAE, NMAE, DPS
    IPs_test={}
    recsTodos_test, IPs_test, NMAE_test, last_visits_test, first_visits_test =Leaspy_Test_personalization(output_directory,btstrp,df_test,leaspy,algo_settings,IPs_test)
    SCORE1_test,SCORE2_test,SCORE3_test,SCORE4_test =Calcular_scores(df_test,ages_test,labels_test,diagnose_test, last_visits_test, first_visits_test,IPs_test, idx_subjects_test)
    
    
    #LEASPY TRAINING --> MAE, NMAE, DPS
    IPs_train={}
    recsTodos_train, IPs_train, NMAE_train, last_visits_train, first_visits_train =Leaspy_Test_personalization(output_directory,btstrp,df_train,leaspy,algo_settings,IPs_train)
    SCORE1_train,SCORE2_train,SCORE3_train,SCORE4_train=Calcular_scores(df_train,ages_train,labels_train,diagnose_train, last_visits_train,first_visits_train, IPs_train, idx_subjects_train)
    
    
    
    
    
    #BAYES
    from sklearn.naive_bayes import GaussianNB
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import accuracy_score
    
    # Agregar la etiqueta de clase a los datos de entrenamiento y prueba
    by_train['label'] = labels_train['cognitive_state']
    by_test['label'] = labels_test['cognitive_state']

    # Seleccionar las características y la etiqueta de clase
    X_train = df_train.drop(columns=['label'])
    y_train = df_train['label']
    X_test = df_test.drop(columns=['label'])
    y_test = df_test['label']

    # Crear el clasificador de Bayes ingenuo gaussiano
    classifier = GaussianNB()

    # Entrenar el clasificador
    classifier.fit(X_train, y_train)

    # Predecir las etiquetas de clase en el conjunto de prueba
    y_pred = classifier.predict(X_test)

    # Calcular la precisión del clasificador
    accuracy = accuracy_score(y_test, y_pred)
    print("Precisión del clasificador de Bayes ingenuo: {:.2f}%".format(accuracy * 100))
    
    
    #LEASPY CLASIFICATION TRAINING --> BAYES
    
    
    
    #LEASPY CLASIFICATION TESTING --> AUC, AGES_ONSET
    
    #LEASPY CLASIFICATION VALIDATION (TRAIN) --> AUC, AGES_ONSET
    
    
    
            
            
    return MAE, NMAE, AUC, percent_PD_CU, percent_PD_MCI, corr_PD_MCI_age, corr_PD_MCI_reserve
            
            
            
    
    