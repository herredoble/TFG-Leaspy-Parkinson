# -*- coding: utf-8 -*-
"""
Created on Sat Feb 17 19:06:32 2024

@author: rroca
"""

import os, sys
import numpy as np    
import pandas as pd    
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

pd.options.display.float_format = '{:.4g}'.format

from leaspy import Leaspy, IndividualParameters, AlgorithmSettings, Data, __watermark__
#from leaspy.io.logs.visualization.plotter import Plotter
from leaspy.io.logs.visualization.plotting import Plotting


from sklearn.model_selection import train_test_split
from funciones.pre_funciones import fill_cogstate_with_NAN, convertTime_PPMI, convert_visit_date, getOnsetTime, get_ni, clean_sdmt, clean_var, percentil_interp

def getdataPPMI():
    file_csv ='C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/Dataset_Apr2020.csv'
    df=pd.read_csv(file_csv)

    df_PD=df.loc[(df['APPRDX']==1)] #SELECCIONA PD
    df_PD=df_PD.reset_index(drop=True)


    cogstate_interp, ID_sinCog = fill_cogstate_with_NAN(df_PD)
    cogstate_interp_float = cogstate_interp.astype(float)
    df_PD['cogstate'] = cogstate_interp_float
    df_PD, ID_sinCog = convertTime_PPMI(df_PD)
    df_PD['date']=convert_visit_date(df_PD['visit_date'])
    df_PD['date'] = pd.to_datetime(df_PD['date'])
    df_PD['onset']=getOnsetTime(df_PD['PATNO'],df_PD['date'],df_PD['cogstate_end']>1,df_PD['convertTimeCogstate'],df_PD['YEAR'])
    #ni = get_ni(df_PD['YEAR'],df_PD['PATNO'].nunique())
    #df_PD['SDMT_sNan']=clean_invalid_CAM_sdmt(df_PD['SDMTOTAL'],ni,df_PD['YEAR'])
    df_PD['Month']=df_PD['YEAR']*12
    df_PD['TIME']=df_PD['age']+df_PD['YEAR']
    df_PD2=df_PD.copy()

    #NORMALIZACION-TP2 (variables decrecientes)
    #normal value 0 and abnormal value 1
    """
    cols_norm=['SDMT_n','LNS_n','HVLTRDLY_n','SFT_n','MEANCAU_n','ABETA_n']
    cols_orig=['SDMTOTAL','lns','HVLTRDLY','sft','mean_caudate','abeta']
    cols_neg=['SDMT_neg', 'LNS_neg','HVLTRDLY_neg','SFT_neg','MEANCAU_neg','ABETA_neg']
    """
    cols_norm=['MOCA_n','GDS_n','UPSIT_n','REM_n','LNS_n','SDMT_n','HVLTRDLY_n','SFT_n','SCOPA_n','MEANPUT_n','MEANCAU_n','ABETA_n','ASYN_n','TAU_n','pTauAB_n','UPDRSTOT_n','UPDRSTOTON_n','UPDRS1_n','UPDRS2_n','UPDRS3_n','UPDRS3ON_n']#'JLO_n','INMEDIATE_n',,'ADL_n'
    cols_orig=['moca','gds','upsit','rem','lns','SDMTOTAL','HVLTRDLY','sft','scopa','mean_putamen','mean_caudate','abeta','asyn','tau','ptau_ab','updrs_totscore','updrs_totscore_on','updrs1_score','updrs2_score','updrs3_score','updrs3_score_on'] #,'jlo','INMEDIATE''adl',
    cols_neg=['MOCA_neg','GDS_neg','UPSIT_neg','REM_neg','LNS_neg','SDMT_neg','HVLTRDLY_neg','SFT_neg','SCOPA_neg','MEANPUT_neg','MEANCAU_neg','ABETA_neg','ASYN_neg','TAU_neg','pTauAB_neg','UPDRSTOT_neg','UPDRSTOTON_neg','UPDRS1_neg','UPDRS2_neg','UPDRS3_neg','UPDRS3ON_neg']#'JLO_neg','INMEDIATE_neg',,'ADL_neg'
    features=['MOCA','GDS','UPSIT','REM','LNS','SDMT','HVLTRDLY','SFT','SCOPA','MEANPUT','MEANCAU','ABETA','ASYN','TAU','pTauAB','UPDRSTOT','UPDRSTOTON','UPDRS1','UPDRS2','UPDRS3','UPDRS3ON']#'JLO_n','INMEDIATE_n',,'ADL_n'
    for i, v in enumerate(cols_orig):
        #df_PD2=clean_var(df_PD2,v)
        df_PD2[cols_neg[i]]=-df_PD2[v]
        feature=df_PD2[cols_neg[i]]
        varname1=f"percent_{v}"
        varname2=f"point_feat_{v}"
        df_PD2[cols_norm[i]], globals()[varname1], globals()[varname2]=percentil_interp(feature,df_PD2['cogstate_end']>1)
    
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_MOCA.npy', percent_moca)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_MOCA.npy', point_feat_moca) 
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_GDS.npy', percent_gds)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_GDS.npy', point_feat_gds)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_UPSIT.npy', percent_upsit)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_UPSIT.npy', point_feat_upsit)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_REM.npy', percent_rem)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_REM.npy', point_feat_rem)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_LNS.npy', percent_lns)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_LNS.npy', point_feat_lns)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_SDMT.npy', percent_SDMTOTAL)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_SDMT.npy', point_feat_SDMTOTAL)
    #np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_JLO.npy', percent_jlo)
    #np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_JLO.npy', point_feat_jlo)
    #np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_INMEDIATE.npy', percent_INMEDIATE)
    #np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_INMEDIATE.npy', point_feat_INMEDIATE)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_HVLTRDLY.npy', percent_HVLTRDLY)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_HVLTRDLY.npy', point_feat_HVLTRDLY)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_SFT.npy', percent_sft)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_SFT.npy', point_feat_sft)
    #np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_ADL.npy', percent_adl)
    #np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_ADL.npy', point_feat_adl) 
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_SCOPA.npy', percent_scopa)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_SCOPA.npy', point_feat_scopa)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_MEANPUT.npy', percent_mean_putamen)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_MEANPUT.npy', point_feat_mean_putamen)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_MEANCAU.npy', percent_mean_caudate)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_MEANCAU.npy', point_feat_mean_caudate)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_ABETA.npy', percent_abeta)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_ABETA.npy', point_feat_abeta)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_ASYN.npy', percent_asyn)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_ASYN.npy', point_feat_asyn) 
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_TAU.npy', percent_tau)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_TAU.npy', point_feat_tau) 
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_PTAUAB.npy', percent_ptau_ab)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_PTAUAB.npy', point_feat_ptau_ab) 
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_UPDSRTOT.npy', percent_updrs_totscore)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_UPDRSTOT.npy', point_feat_updrs_totscore) 
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_UPDRSTOTON.npy', percent_updrs_totscore_on)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_UPDRSTOTON.npy', point_feat_updrs_totscore_on) 
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_UPDRS1.npy', percent_updrs1_score)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_UPDRS1.npy', point_feat_updrs1_score) 
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_UPDRS2.npy', percent_updrs2_score)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_UPDRS2.npy', point_feat_updrs2_score) 
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_UPDRS3.npy', percent_updrs3_score)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_UPDRS3.npy', point_feat_updrs3_score) 
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/percent_UPDRS3ON.npy', percent_updrs3_score_on)
    np.save('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/percents_and_pfeat/pfeat_UPDRS3ON.npy', point_feat_updrs3_score_on) 
    
    #df_PD2.to_csv('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/TP2_multivar/data/data_inicio_tp2.csv', index=False)
    return df_PD2, cols_norm, cols_orig, features






