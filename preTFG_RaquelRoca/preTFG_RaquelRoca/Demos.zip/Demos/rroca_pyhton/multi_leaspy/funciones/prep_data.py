# -*- coding: utf-8 -*-
"""
Created on Sat Feb 17 19:35:55 2024

@author: rroca
"""
import os
from scipy import stats
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style('whitegrid')
pd.options.display.float_format = '{:.4g}'.format
# import main classes from Leaspy package
from leaspy import Leaspy, Data, AlgorithmSettings, IndividualParameters, __watermark__
from leaspy.io.logs.visualization.plotting import Plotting
from sklearn.model_selection import train_test_split
data_path = lambda *p: os.path.join('./data', *p)
# Watermark trace with all packages versions
__watermark__

def prep_data(df, df_orig, classes, feature_names_norm, features_names_orig,features):
    
    #VECTOR 3D??? --> VER SU HACE FALTA
    
    #PARTE1: DATA 
    """
    df = pd.DataFrame({
        'ID': datai['PATNO'].astype(str),
        'TIME': datai['TIME'],
        #'DX':datai['DX'],    --> NO PUEDE TENER STRINGS PARA LEASPY??
        'ABETA': datai['ABETA_n'],
        'HVLTRDLY':datai['HVLTRDLY_n'],
        'LNS': datai['LNS_n'],
        'MEANCAU':datai['MEANCAU_n'],
        'SDMT': datai['SDMT_n'],
        'SFT': datai['SFT_n']
    })
      
    df_orig = pd.DataFrame({
        'ID': datai['PATNO'].astype(str),
        'TIME': datai['TIME'],
        #'DX':datai['DX'],
        'ABETA': datai['abeta'], 
        'HVLTRDLY':datai['HVLTRDLY'],
        'LNS': datai['lns'],
        'MEANCAU':datai['mean_caudate'],
        'SDMT': datai['SDMTOTAL'],
        'SFT': datai['sft']           
    })
    """
    """
    df=pd.DataFrame({
       'ID': datai['PATNO'].astype(str),
       'TIME': datai['TIME'],
       #'DX':datai['DX'],    --> NO PUEDE TENER STRINGS PARA LEASPY??
       })
    df_orig=pd.DataFrame({
        'ID': datai['PATNO'].astype(str),
        'TIME': datai['TIME'],
        #'DX':datai['DX'],
        })
    
    for i,v in enumerate(features):
        df[v]=datai[feature_names_norm[i]]
        df_orig[v]=datai[feature_names_norm[i]]
    """
    df = df.rename(columns={'PATNO': 'ID'})
    df_orig = df_orig.rename(columns={'PATNO': 'ID'})
    df = df.set_index(["ID","TIME"], verify_integrity=True).sort_index()
    df_orig = df_orig.set_index(["ID","TIME"], verify_integrity=True).sort_index()
    
    n_subjects = df.index.get_level_values('ID').unique().shape[0]
    print(f'{n_subjects} subjects in the dataset.')

    
    # PARTE2: DIAGNOSTICO
    grouped = df.groupby('ID')
    patient_states = grouped['DX'].apply(list)
    labels = pd.DataFrame(patient_states.tolist(), index=patient_states.index)
    ultima_visita_index = labels.apply(lambda row: row.last_valid_index(), axis=1)
    estado_ultima_visita = labels.lookup(labels.index, ultima_visita_index)
    diagnose=pd.DataFrame({'lbl_init':labels.iloc[:,0],'lbl_end':estado_ultima_visita})

    # PARTE3: QUITAR PACIENTES CON POCAS VISITAS
    visitas_por_paciente = df.groupby('ID').size()
    pacientes_con_suficientes_visitas = visitas_por_paciente[visitas_por_paciente >= 2].index
    df = df.loc[df.index.get_level_values('ID').isin(pacientes_con_suficientes_visitas)]
    diagnose = diagnose.loc[diagnose.index.isin(pacientes_con_suficientes_visitas)]
    
    # PARTE4: QUITAR PACIENTES CON MCI(1) Y CN(2)
    pacientes_mci_primero_cn_despues = diagnose[(diagnose['lbl_init'] == classes[1]) & (diagnose['lbl_end'] == classes[0])].index
    df = df[~df.index.get_level_values('ID').isin(pacientes_mci_primero_cn_despues)]
    diagnose = diagnose[~diagnose.index.isin(pacientes_mci_primero_cn_despues)]

    # PARTE5: DIVIDIR TRAIN, TEST, VALID
    idx_subjects=df.index.get_level_values('ID').unique()
    idx_subjects_train, idx_subjects_test = train_test_split(idx_subjects, test_size=0.2, random_state=42)
    idx_subjects_train = np.sort(idx_subjects_train)
    idx_subjects_test = np.sort(idx_subjects_test)
    #df_train = df.loc[idx_subjects_train]
    #df_test = df.loc[idx_subjects_test]

    df.to_csv('C:/Users/rroca/Desktop/TFG/Demos/rroca_pyhton/multi_leaspy/data/dfTP2.csv', index=True)

    return df, df_orig, diagnose, labels, idx_subjects_train, idx_subjects_test