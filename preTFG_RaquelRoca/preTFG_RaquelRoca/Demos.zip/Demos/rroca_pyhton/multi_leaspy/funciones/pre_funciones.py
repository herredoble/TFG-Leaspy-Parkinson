# -*- coding: utf-8 -*-
"""
Created on Sat Nov 18 12:03:47 2023

@author: rroca
"""

import numpy as np
import pandas as pd
from datetime import datetime
from scipy.interpolate import interp1d

#In[51]:
#Guardar en ID_SinCog los pacientes con cogstate todo NAN
def fill_cogstate_with_NAN(PPMI):
    
    from funciones.pre_funciones2 import estimate_cogstate_sin, subjects_sinCogstate, interp_cogstate
    
    ID_sinCog = subjects_sinCogstate(PPMI['PATNO'], PPMI['cogstate'])
    cogstate = estimate_cogstate_sin(PPMI['PATNO'], PPMI['cogstate'],
                                     PPMI['MCI_testscores'], PPMI['NP1COG'], ID_sinCog)

    PPMI['cogstate'] = cogstate
    cogstate_interp = PPMI['cogstate']

    ID = np.unique(PPMI['PATNO'])
    ID_sinCog = []
    for i in range(len(ID)):
        mask_subj = PPMI['PATNO'] == ID[i]
        tbl_subj = PPMI[mask_subj]
        cogstate_subj = tbl_subj['cogstate'].values

        mask_cog = ~np.isnan(cogstate_subj)
        if len(tbl_subj) == np.sum(mask_cog):
            continue
        elif np.sum(mask_cog) == 0:
            ID_sinCog.append(ID[i])
        else:
            NP1COG_subj = tbl_subj['NP1COG'].values
            cogstat_interp_sub = interp_cogstate(cogstate_subj, NP1COG_subj)
            cogstate_interp[mask_subj] = cogstat_interp_sub

    return cogstate_interp, ID_sinCog


        

    
        
#In [52]:
#convertTime_PPMI

def convertTime_PPMI(PPMI):
    unique_ID = PPMI["PATNO"].unique()

    # Convert arrays to DataFrame for proper indexing and assignment
    cogstate = pd.Series(np.full(len(PPMI), np.nan), name='cogstate')
    MCI_testscores = pd.Series(np.full(len(PPMI), np.nan), name='MCI_testscores')
    np1cog = pd.Series(np.full(len(PPMI), np.nan), name='np1cog')

    convertTimeCogstate = pd.Series(np.full(len(PPMI), np.nan), name='convertTimeCogstate')
    convertTimeMCI_test = pd.Series(np.full(len(PPMI), np.nan), name='convertTimeMCI_test')
    convertTimeNp1cog = pd.Series(np.full(len(PPMI), np.nan), name='convertTimeNp1cog')

    ID_sinCog = []
    

    for i in range(len(unique_ID)):
    #j=[2224, 2225, 2226]
    #for i in j:
        index = PPMI.index[PPMI['PATNO'] == unique_ID[i]]

        PD_subj = PPMI.loc[index]
        cogstate_subj = PD_subj['cogstate']
        MCI_testscores_subj = PD_subj['MCI_testscores']
        np1cog_subj = PD_subj['NP1COG']
        year_subj = PD_subj['YEAR']

        # Criteria cogstate: 1(HC),2(MCI), 3(Dementia)
        year_cog = year_subj[~np.isnan(cogstate_subj)]
        cogstate_subj = cogstate_subj[~np.isnan(cogstate_subj)]
        if len(cogstate_subj) > 0:
            cogstate.loc[index] = cogstate_subj.iloc[-1]
            if cogstate_subj.iloc[-1] > 1:
                convertTimeCogstate.loc[index] = np.tile(min(year_cog[cogstate_subj > 1]), len(index))
            else:
                convertTimeCogstate.loc[index] = np.tile(max(year_cog), len(index))
        else:
            ID_sinCog.append((1, unique_ID[i]))

        # Criteria MCI_testscores: 0 (HC), 1(MCI)
        year_MCI = year_subj[~np.isnan(MCI_testscores_subj)]
        MCI_testscores_subj = MCI_testscores_subj[~np.isnan(MCI_testscores_subj)]
        if len(MCI_testscores_subj) > 0:
            MCI_testscores.loc[index] = MCI_testscores_subj.iloc[-1]
            if MCI_testscores_subj.iloc[-1] > 0:
                convertTimeMCI_test.loc[index] = np.tile(min(year_MCI[MCI_testscores_subj > 0]), len(index))
            else:
                convertTimeMCI_test.loc[index] = np.tile(max(year_MCI), len(index))
        else:
            print(f"Subject {unique_ID[i]} without MCI testscores data")
            ID_sinCog.append((2, unique_ID[i]))

        # Criteria np1cog: 0 (HC), 1(Slight), 2(Mild), 3 (Moderate), 4(Severate)
        year_cog = year_subj[~np.isnan(np1cog_subj)]
        np1cog_subj = np1cog_subj[~np.isnan(np1cog_subj)]
        if len(np1cog_subj) > 0:
            np1cog.loc[index] = np1cog_subj.iloc[-1]
            if np1cog_subj.iloc[-1] > 1:
                convertTimeNp1cog.loc[index] = np.tile(min(year_cog[np1cog_subj > 1]), len(index))
            else:
                convertTimeNp1cog.loc[index] = np.tile(max(year_cog), len(index))
        else:
            print(f"Subject {unique_ID[i]} without np1cog data")
            ID_sinCog.append((3, unique_ID[i]))


    print (ID_sinCog)
    print (len(ID_sinCog))
    ID_sinCog = [tupla[1] for tupla in ID_sinCog]
    
    for i in range(len(ID_sinCog)):
        mask_subj=PPMI["PATNO"]==ID_sinCog[i]
        MCI_test_subj=(PPMI.loc[mask_subj==True, 'MCI_testscores'])+1
        NP1COG_subj=PPMI.loc[mask_subj==True, 'NP1COG']
        cog_subj = (PPMI.loc[mask_subj==True, 'cogstate'])
        
        if NP1COG_subj.isna().any():
            ultimo_valor_no_nan = NP1COG_subj.dropna().iloc[-1]
            NP1COG_subj.fillna(ultimo_valor_no_nan, inplace=True)
            
        mask_NP1COG = ~np.isnan(NP1COG_subj)
        if np.sum(mask_NP1COG) > 0:
            cog_subj[mask_NP1COG] = NP1COG_subj[mask_NP1COG]+1
        else:
            print("ERROR PASANDO DATOS")
            
        index = PPMI.index[PPMI['PATNO'] == ID_sinCog[i]]
        cogstate.loc[index] = cog_subj.iloc[-1]

    PPMI['cogstate_end'] = cogstate
    PPMI['MCI_testscores_end'] = MCI_testscores
    PPMI['np1cog_end'] = np1cog

    PPMI['convertTimeCogstate'] = convertTimeCogstate
    PPMI['convertTimeMCI_test'] = convertTimeMCI_test
    PPMI['convertTimeNp1cog'] = convertTimeNp1cog

    return PPMI, ID_sinCog


def convert_visit_date(visit_date):
    n_visit = len(visit_date)
    month_str = [visit_date[i][:3] for i in range(n_visit)]
    
    month_dict = {
        'JAN': 1, 'FEB': 2, 'MAR': 3, 'APR': 4, 'MAY': 5, 'JUN': 6,
        'JUL': 7, 'AUG': 8, 'SEP': 9, 'OCT': 10, 'NOV': 11, 'DEC': 12
    }
    
    month = [month_dict.get(m, -1) for m in month_str]
    year = [int(visit_date[i][3:]) for i in range(n_visit)]
    
    # Construct date array
    date = [datetime(year[i], month[i], 1) for i in range(n_visit)]
    #date_objects = [datetime.strptime(date_str, '%Y-%b-%d') for date_str in date]
    
    return date



def getOnsetTime(ID, date, convert, convertTime, YEAR):
    onset = np.full(len(ID), np.nan)
    

    # Convert
    RID = np.unique(ID[convert == 1])
    for i in range(len(RID)):
        index = np.where(ID == RID[i])[0]
        convertTime_year = convertTime[index[0]]
        years = YEAR[index]
        idx = np.where(years == convertTime_year)[0]
        time_zero = date[index[idx]]
        
        try:
            Delta_days = (date[idx] - date[idx - 1]).days / 2
            for j in index:
                onset[j] = ((date[j] - time_zero).days + Delta_days) / 30.4167 / 12
        except:
            for j in index:
                onset[j] = (date[j] - date[index[0]]).days / 30.4167 / 12
            

    RID = np.unique(ID[convert == 0])
    for i in range(len(RID)):
        index = np.where(ID == RID[i])[0]
        time_zero = date[index[-1]]
        for j in index:
            onset[j] = (date[j] - time_zero).days / 30.4167 / 12

    return onset


def get_ni(time_visit, numIDs):
    # Calculating number of images
    baseline = np.where(time_visit == 0)[0]
    numScans = len(time_visit)
    ni = np.diff(np.append(baseline, numScans))  # Compute differences between baseline indices
    ni[-1] = numScans - baseline[-1] # Last entry
    sum_ni=np.sum(ni)
    # Checking errors
    if len(ni) != numIDs:
        print('Error calculating ni: There are more scans in baseline than subjects')
    if np.sum(ni) != numScans:
        print('Error calculating ni')

    return ni

"""
def clean_invalid_CAM_sdmt(sdmt,ni,time_visit):
    new_sdmt_values = sdmt.copy()
    num_patients = len(ni)
    num_img = 0
    
    for i in range(num_patients):
        tmp_sdmt = sdmt.iloc[num_img:num_img+ni[i]]
        invalid_visits = np.isnan(tmp_sdmt)
        
        if np.sum(invalid_visits) > 0:
            valid_idx = np.where(~np.isnan(tmp_sdmt))[0]
            valid_sdmt = tmp_sdmt.iloc[valid_idx]
            valid_times = time_visit.iloc[num_img:num_img+ni[i]].iloc[valid_idx]
            no_valid_idx = np.where(np.isnan(tmp_sdmt))[0]
            no_valid_times = time_visit.iloc[num_img:num_img+ni[i]].iloc[no_valid_idx]
            
            if len(valid_idx) > 1:
                new_sdmt_values.iloc[num_img+no_valid_idx] = np.interp(
                    no_valid_times, valid_times, valid_sdmt, left=np.nan, right=valid_sdmt.iloc[-1])
            else:
                if np.all(np.isnan(valid_sdmt)):
                    new_sdmt_values.iloc[num_img+no_valid_idx] = np.nanmean(sdmt)
                else:
                    new_sdmt_values.iloc[num_img+no_valid_idx] = valid_sdmt.iloc[0]
        
        num_img += ni[i]
    
    return new_sdmt_values
    """


def clean_sdmt(df):  #VER SI HACE FALTA RESETEAR YEAR O ALGO ASI ????
    df.dropna(subset=['SDMTOTAL'], inplace=True)
    df.reset_index(drop=True, inplace=True)
    return df
    

def clean_var(df,f):
    df.dropna(subset=[f], inplace=True)
    df.reset_index(drop=True, inplace=True)
    return df


def percentil_interp(features, group, prob=None, feat=None):
    feat2per = np.full_like(features, np.nan)
    
    if isinstance(features, pd.Series):
        features_fr = features.to_frame()
        features_fr.reset_index(drop=True, inplace=True)
        
    if prob is not None and feat is not None:
        # Utilizar np.interp solo para los valores que no son NaN
        not_nan_mask = ~np.isnan(features)
        feat2per[not_nan_mask] = np.interp(feat[not_nan_mask], prob, features[not_nan_mask])
    else:
        # BALANCE SAMPLES:
        gr_name, num_samples = np.unique(group, return_counts=True)
        max_samples = np.max(num_samples)
        feat_extra = []

        for i in range(len(gr_name)):
            if (max_samples - num_samples[i] > 0):
                feat_b = features[group == gr_name[i]]  # 512
                index = np.random.randint(num_samples[i], size=max_samples - num_samples[i])  # 1100
                feat_extra = feat_b.iloc[index]

        balanced_features = np.concatenate([features, np.array(feat_extra)])
        
        valid_values = balanced_features[~np.isnan(balanced_features)]
        hist, edges = np.histogram(valid_values, bins='auto', density=True)
        
        prob = np.cumsum(hist) / np.sum(hist)
        feat = edges[:-1]
        
        feat[1] = feat[0] + (feat[2] - feat[1]) / 2.0

        # Utilizar np.interp solo para los valores que no son NaN
        not_nan_mask = ~np.isnan(features)
        feat2per[not_nan_mask] = np.interp(features[not_nan_mask], feat, prob)
    return feat2per, prob, feat

"""
def percentil_interp(features, group, prob=None, feat=None):
    feat2per = np.zeros_like(features)
    
    if isinstance(features, pd.Series):
        features_fr = features.to_frame()
        features_fr.reset_index(drop=True, inplace=True)
        
    if prob is not None and feat is not None:
        feat2per = np.interp(feat, prob, features)
    else:
        #BALANCE SAMPLES:
        gr_name, num_samples = np.unique(group, return_counts=True)
        max_samples = np.max(num_samples)
        feat_extra = []

        for i in range(len(gr_name)):
            if (max_samples - num_samples[i] > 0):
                feat_b = features[group == gr_name[i]]  #512
                index = np.random.randint(num_samples[i], size=max_samples - num_samples[i]) #1100
                feat_extra=feat_b.iloc[index]

        balanced_features = np.concatenate([features, np.array(feat_extra)])

        hist, edges = np.histogram(balanced_features, bins='auto', density=True)
        
        prob = np.cumsum(hist) / np.sum(hist)
        feat = edges[:-1]
        
        feat[1] = feat[0] + (feat[2] - feat[1]) / 2.0
       
        feat2per = np.interp(features, feat, prob)

    return feat2per, prob, feat
    """
    
