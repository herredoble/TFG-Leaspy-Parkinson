# -*- coding: utf-8 -*-
"""
Created on Wed Mar  6 08:39:33 2024

@author: rroca
"""

#MAE:
# - Seleccionar para cada bootstrap las reconstrucciones en los tiempos de las 
#   observaciones. Es decir, tenemos seis variables, y diez reconstrucciones de 
#   esas variables (1 por bootstrap). Si tenemos cuatro observaciones en 4 tiempos
#   distintos, tendremos un dataframe 6 variables x 10 reconstrucciones (60 columnas) 
#   y cuatro filas correspondientes a las filas de los tiempos iguales a los de 
#   observaciones.

# MAE= Para cada modelo, es la media de la diferencias entre las estimaciones y las muestras en
#      cada tiempo muestreado. por lo que tendremos una tabla de 6x10, cada variable tiene un MAE 

import numpy as np
import pandas as pd
from datetime import datetime
from scipy.interpolate import interp1d
# import main classes from Leaspy package
from leaspy import Leaspy, Data, AlgorithmSettings, IndividualParameters, __watermark__
from leaspy.io.logs.visualization.plotting import Plotting
import os
data_path = lambda *p: os.path.join('./data', *p)
 
def calculate_mae(samples, estimate):
    print(samples)
    print(estimate)
    bstrp = estimate.shape[1]
    mae_feat=[]
    filas_con_nan = samples[samples.isna().any(axis=1)].index

    samples = samples.drop(index=filas_con_nan)
    estimate = estimate.drop(index=filas_con_nan)
    for r in range(bstrp):        
        resta=np.array(samples.iloc[:,0].values-estimate.iloc[:,r].values)
        absoluto=np.abs(resta)
        media=np.mean(absoluto)
        #mae_feat[r]=np.mean(np.abs(estimate.iloc[:,r].values-samples.values))
        mae_feat.append(media)
        print(mae_feat[r])

    return mae_feat

def Obtener_NMAE(recs_btstrps, df_test, btstrp, features, idx_test, timepoints_all): 
    NMAE_subjectsXbstrpsXfeats={}
    #x=3001
    #x=3012
    #x=3021
    #x=3056
    
    for x in idx_test:
        print(x)
        timepoints=timepoints_all[x]
        df_pred=df_test[df_test.index.get_level_values('ID')==x]
        observations = df_pred.reset_index().copy()
        observations.drop('ID', axis=1, inplace=True)
        observations.set_index('TIME', inplace=True)
        TIME_obs=observations.index.get_level_values('TIME')
        indices_cercanos = [np.argmin(np.abs(timepoints - numero)) for numero in TIME_obs]
        df_estimations_norm=recs_btstrps[x].iloc[indices_cercanos]
        
        nmae_list=[]
    
        for i, a in enumerate(features):
            samples_n=observations[a].reset_index(drop=True).to_frame()
            #samples_o=observations_orig[a].reset_index(drop=True).to_frame()
            
            feat_estim_n = df_estimations_norm.filter(like=a).reset_index(drop=True)
            #feat_estim_o = df_estimations_orig.filter(like=a).reset_index(drop=True)
            
            nmae_list.append(calculate_mae(samples_n, feat_estim_n))
    
    
        nmae_list_transposed = list(map(list, zip(*nmae_list)))
        NMAE = pd.DataFrame(nmae_list_transposed, columns=features)
    
        #medias = NMAE.mean()
        #NMAE=NMAE.append(medias, ignore_index=True)
        #NMAE=NMAE.rename(index={len(NMAE)-1:'Media'})
        NMAE_subjectsXbstrpsXfeats[x]=NMAE
        
        
        
    #CALCULAR LA MEDIA DE TODOS LOS SUJETOS PARA CADA BOOSTRAP
    #df = pd.DataFrame.from_dict(NMAE_subjectsXbstrpsXfeats, orient='index')

    # Calcular la media para cada paciente en cada boostrap
    #media_por_bootstrap = df['NMae'].mean(axis=1)
    
    NMAE_means_df = pd.DataFrame()

    # Iteramos sobre las variables
    for variable in NMAE_subjectsXbstrpsXfeats[x].columns:
        # Inicializamos una lista para almacenar las medias de cada bootstrap
        means = []
        # Iteramos sobre los bootstraps
        for i in range(10):  # Suponiendo que siempre tienes 10 bootstraps
            # Sumamos los valores de todos los sujetos para esta variable y este bootstrap
            total = sum(df[variable][i] for df in NMAE_subjectsXbstrpsXfeats.values())
            # Calculamos la media dividiendo por el número total de sujetos
            mean = total / len(NMAE_subjectsXbstrpsXfeats)
            # Añadimos la media a la lista de medias
            means.append(mean)
        # Añadimos las medias al DataFrame con el nombre de la variable como columna
        NMAE_means_df[variable] = means
            
    # Visualizamos el DataFrame con las medias
    print(NMAE_means_df)
    
    
    return NMAE_subjectsXbstrpsXfeats