# -*- coding: utf-8 -*-
"""
Created on Wed Nov 29 15:25:47 2023

@author: rroca
"""
import numpy as np
import pandas as pd
from datetime import datetime
from scipy.interpolate import interp1d

def estimate_cogstate_sin(PATNO, cogstate, MCI_testscores, NP1COG, ID_sinCog):
    cogstate_est = cogstate.copy()
            
    for i in range(len(ID_sinCog)):
        mask_subj=PATNO==ID_sinCog[i]
        MCI_test_subj=MCI_testscores[mask_subj] + 1
        NP1COG_subj = (NP1COG[mask_subj] > 1) + 1
        
        cog_subj = pd.Series(np.nan, index=MCI_test_subj.index)
        mask_MCI_test = ~np.isnan(MCI_test_subj)
        mask_NP1COG = ~np.isnan(NP1COG_subj)             

        mask_x=(MCI_test_subj == NP1COG_subj)
        mask_equal_criteria = np.logical_and(np.logical_and(mask_x, mask_MCI_test), mask_NP1COG)
        
        if np.sum(mask_equal_criteria) > 0:
            cog_subj[mask_equal_criteria] = MCI_test_subj.loc[mask_equal_criteria]
        else:
            MCI_ = MCI_test_subj[mask_MCI_test]
            NPI_ = NP1COG_subj[mask_NP1COG]
            idx = mask_NP1COG.index
            
            if len(idx)>0:
                cog_subj.at[idx[0]] = min(MCI_.iloc[0], NPI_.iloc[0])
                cog_subj.at[idx[-1]] = min(MCI_.iloc[-1], NPI_.iloc[-1])
                
        cogstate_est[mask_subj] = cog_subj

    return cogstate_est

def subjects_sinCogstate(PATNO, cogstate):
    ID = np.unique(PATNO)
    ID_sinCog = np.full(len(ID), np.nan)
    for i in range(len(ID)):
        cogstate_subj = cogstate[PATNO == ID[i]]
        mask_cog = ~np.isnan(cogstate_subj)
        if np.sum(mask_cog) == 0:
            ID_sinCog[i] = ID[i]

    ID_sinCog = ID_sinCog[~np.isnan(ID_sinCog)]
    return ID_sinCog

def interp_cogstate(cogstate_subj, NP1COG_subj):
    cogstat_interp = cogstate_subj.copy()
    mask_nan = ~np.isnan(cogstate_subj)
    cogstate_subj_know = cogstate_subj[mask_nan]
    diag = np.unique(cogstate_subj_know)
    if len(diag) == 1:
        if diag == 1:
            cogstat_interp[~mask_nan] = diag
        else:
            cogstat_interp[~mask_nan] = (NP1COG_subj[~mask_nan] > 1) + 1
            cogstat_interp[-1] = cogstate_subj_know[-1]
    elif cogstate_subj_know[-1] == 1:
        cogstat_interp[~mask_nan] = 1
    else:
        idx = np.where(cogstat_interp > 1)[0][0]
        mask_aux = np.ones(len(cogstat_interp), dtype=bool)
        mask_aux[idx:] = False
        cogstat_interp[mask_aux & ~mask_nan] = 1
        cogstat_interp[mask_aux == ~mask_nan] = cogstat_interp[idx]
        cogstat_interp[-1] = cogstate_subj_know[-1]

    return cogstat_interp