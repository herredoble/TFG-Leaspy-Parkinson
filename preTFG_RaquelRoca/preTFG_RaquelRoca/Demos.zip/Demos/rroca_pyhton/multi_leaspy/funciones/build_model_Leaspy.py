# -*- coding: utf-8 -*-
"""
Created on Tue Feb 20 18:10:29 2024

@author: rroca
"""
import numpy as np
import pandas as pd
from datetime import datetime
from scipy.interpolate import interp1d
# import main classes from Leaspy package
from leaspy import Leaspy, Data, AlgorithmSettings, IndividualParameters, __watermark__
from leaspy.io.logs.visualization.plotting import Plotting
import os
data_path = lambda *p: os.path.join('./data', *p)

def build_model_Leaspy(df_train, ages_train,labels_train, diagnose_train, idx_subjects_train, classes, btstrp,leaspy,leaspy_plotting,algo_settings, fich_name):
   
    #K1, I1, J1 = np.shape(df_train)
    #INICIALIZAR MATRICES GUARDAR DATOS BTSTRP...
    sample_size=int(len(idx_subjects_train)*0.8)
    sample_size_val=int((len(idx_subjects_train)*0.2)+1)
    Idx_train = np.zeros((sample_size, btstrp), dtype=int)
    Idx_valid = np.zeros((sample_size_val, btstrp), dtype=int)
    parameters = {'betas': [], 'g': [], 'noise_std': [], 'sources_mean': [], 'sources_std': [], 'tau_mean': [], 'tau_std': [], 'v0': [], 'xi_mean': [], 'xi_std': []}
    
    #num_points=......
    #Contruye el modelo en cada btstrp con los sujetos train en cada uno
    for i in range(btstrp):
        print(f'bootstrap {i + 1}> ', end='')  # mostrar el número de bootstrap
        
        idx_btstrp = np.random.choice(idx_subjects_train, sample_size, replace=False)
        idx_train=np.sort(idx_btstrp)
        idx_valid = np.setdiff1d(idx_subjects_train, idx_train)
        Idx_train[:,i]=idx_train
        Idx_valid[:,i]=idx_valid
        
        #LEASPY_TRAIN
        # CALIBRATION --> Obtencion parametros y trayectoria grupal media
        data_train = Data.from_dataframe(df_train.loc[idx_train])
        leaspy.fit(data_train, settings=algo_settings)
          
        leaspy.model.parameters
        parameters['betas'].append(leaspy.model.parameters['betas'].numpy())
        parameters['g'].append(leaspy.model.parameters['g'].numpy())
        parameters['noise_std'].append(leaspy.model.parameters['noise_std'].numpy())
        parameters['sources_mean'].append(leaspy.model.parameters['sources_mean'].numpy())
        parameters['sources_std'].append(leaspy.model.parameters['sources_std'].numpy())
        parameters['tau_mean'].append(leaspy.model.parameters['tau_mean'].numpy())
        parameters['tau_std'].append(leaspy.model.parameters['tau_std'].numpy())
        parameters['v0'].append(leaspy.model.parameters['v0'].numpy())
        parameters['xi_mean'].append(leaspy.model.parameters['xi_mean'].numpy())
        parameters['xi_std'].append(leaspy.model.parameters['xi_std'].numpy())
        features = leaspy.model.features
        noise=leaspy.model.parameters['noise_std']
        
        print('Standard deviation of the residual noise for the feature:')
        for n, f in zip(noise, features):
            print(f'- {f}: {n*100:.2f}%')
            
        output_directory = os.path.join("outputs", fich_name)
        if not os.path.exists(output_directory):
           os.makedirs(output_directory) 
        
        # Guardar el modelo en un archivo .json con nombre "model_i.json"
        model_filename = f"model_parameters{i}.json"
        model_path = os.path.join(output_directory, model_filename)

        leaspy.save(model_path)
    
        
    return parameters, leaspy, Idx_train, output_directory