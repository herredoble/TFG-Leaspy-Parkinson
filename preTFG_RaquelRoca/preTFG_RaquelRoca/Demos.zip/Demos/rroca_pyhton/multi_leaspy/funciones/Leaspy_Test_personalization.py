# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 18:35:22 2024

@author: rroca
"""
import numpy as np
import pandas as pd
from datetime import datetime
from scipy.interpolate import interp1d
# import main classes from Leaspy package
from leaspy import Leaspy, Data, AlgorithmSettings, IndividualParameters, __watermark__
from leaspy.io.logs.visualization.plotting import Plotting
import os
data_path = lambda *p: os.path.join('./data', *p)
from funciones.Obtener_NMAE import Obtener_NMAE

def Leaspy_Test_personalization(output_dir, btstrp,df_test,leaspy,algo_settings, IPs):
    recs_todosXbstrp=[]
    timepoints_todosXbstrp=[]
    for i in range(btstrp):
        model_filename = f"model_parameters{i}.json"
        model_path = os.path.join(output_dir, model_filename)
        leaspy=leaspy.load(model_path)
        data_test = Data.from_dataframe(df_test)
        
        #################
        # PERSONALISATION
        settings_personalization = AlgorithmSettings('scipy_minimize', seed=0)
        ip = leaspy.personalize(data_test, settings_personalization)
        
        ######################################
        #RECONTRUCTION, IMPUTATION, PREDICTION (CON VALORES NORMALIZADOS)
        idx_test=df_test.index.get_level_values('ID').unique()
        reconstruciones_norm={}
        timepoints_all={}
        visitas_finales={}
        visitas_iniciales={}
        
        #PACIENTE A PACIENTE DE TEST
        for x in idx_test:
            #df_pred_orig=df_orig[df_orig['ID']==x]
            df_pred=df_test[df_test.index.get_level_values('ID')==x]
            visita_inicial=df_pred.index.get_level_values('TIME').min()
            visita_final=df_pred.index.get_level_values('TIME').max()
            visitas_finales[x]=visita_final
            visitas_iniciales[x]=visita_inicial
            año_min_det=visita_inicial-1
            año_max_det=visita_final +5
            
            timepoints = np.linspace(año_min_det, año_max_det, 100)
            reconstruction_norm = leaspy.estimate({x: timepoints}, ip)
            
            col = leaspy.model.features
            df_rec_sujnorm=[]

            for j in range(100):
                d3 = {k: v[j] for k, v in reconstruction_norm.items()}
                i=str(i)
                dw = pd.DataFrame.from_dict(d3, orient='index', columns = [s+"_model_"+i for s in col])
                df_rec_sujnorm.append(dw)
            df_rec_sujnorm = pd.concat(df_rec_sujnorm, axis=0).reset_index(drop=True)
            reconstruciones_norm[x]=df_rec_sujnorm  
            timepoints_all[x]=timepoints
            
        recs_todosXbstrp.append(reconstruciones_norm)
        #timepoints_todosXbstrp.append(timepoints_all)

    
    recs_subjectsXbstrp = {}
    for x in idx_test:
        df_sx = pd.DataFrame()
        for b in range(btstrp):
            df_sx_bx = recs_todosXbstrp[b][str(x)]
            df_sx=pd.concat([df_sx,df_sx_bx], axis=1)

        # Concatenar todos los DataFrames almacenados en la lista
        recs_subjectsXbstrp[x]=df_sx
       
    #CALCULAR NMAE_TEST
    NMAE=Obtener_NMAE(recs_subjectsXbstrp, df_test, btstrp, leaspy.model.features, idx_test, timepoints_all)
    
    
    
    
    
    #ARREGLAR VARIABLE PARAMETERS EN BUILD
        
        
    return recs_todosXbstrp, ip, NMAE, visitas_finales, visitas_iniciales
            
            
            
            
            