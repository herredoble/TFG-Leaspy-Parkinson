# In[50]:


import pandas as pd
import scipy.stats as stats
#from tabulate import tabulate
#import tabulate as tabulate
import numpy as np
from scipy.stats import f_oneway, ttest_ind, chi2_contingency
from statsmodels.stats.multicomp import pairwise_tukeyhsd
#import regex as re

#file_xlsx = './data/PPMI_Original_Cohort_BL_to_Year_5_Dataset_Apr2020.xlsx'
file_csv = './data/PPMI_Original_Cohort_BL_to_Year_5_Dataset_Apr2020_csv.csv'
#In [51]:
#df=pd.read_excel(file_xlsx)
df=pd.read_csv(file_csv)
#In [52]:

#NM subjects????    
data_nm={}
data_nm["Group"]=["Subjects","Female","APOE4","Age","Education", "GDS","UPSIT","REM","UPDRS3", "UPDRSTOT","UPDRSTOTOM","UPDRS1","UPDRS2","UPDRS3ON","MOCA","LNS","SDMT","JLO","INMEDIATE","HVLTRDLY","SFT","ADL","SCOPA", "ABETA", "ASYN", "TAU","PTAU", "pTauAB",  "MEANPUT","MEANCAU"]

#for dx_category in ["HC_CU", "HC_MCI", "PD_CU", "PD_MCI","PD_DEMENTIA"]:
for dx_category in ["PD", "HC"]:
    #first filtering by group
    if dx_category=="HC":
        filtered_df=df[(df["APPRDX"]==2)]
    else:
        filtered_df=df[(df["APPRDX"]==1)]
        
    #Second filtering at bl
    filtered_df = filtered_df[filtered_df["YEAR"] == 0]
    
    #SUBJECTS
    filtered_subjects=filtered_df["PATNO"].nunique()
    subjects=df["PATNO"].nunique()
    filtered_subjects_percentage = f"{(filtered_subjects/subjects)*100:.1f}%"
    
    #FEMALE
    female_subjects = filtered_df[filtered_df["gen"] == 2]["PATNO"].nunique()
    female_percentage = f"{(female_subjects/filtered_subjects)*100:.1f}%"
   
    #APOE4
    APOE_e4_subjects = filtered_df[filtered_df["APOE_e4"] > 0]["PATNO"].nunique()
    APOE_e4_n = filtered_df[(filtered_df["APOE_e4"] >=0) & (filtered_df["APOE_e4"]<=2)]["PATNO"].nunique()
    APOE_e4_percentage = f"{(APOE_e4_subjects/APOE_e4_n)*100:.1f}%"
    
    #AGE
    age_mean = filtered_df["age"].mean()
    age_std = filtered_df["age"].std()
    age_min = filtered_df["age"].min()
    age_max = filtered_df["age"].max()
    age_stats = f"{age_mean:.1f} ({age_std:.1f}) ({age_min:.1f}, {age_max:.1f})"
    
    #EDUCATION
    education_mean = filtered_df["EDUCYRS"].mean()
    education_std = filtered_df["EDUCYRS"].std()
    education_min = filtered_df["EDUCYRS"].min()
    education_max = filtered_df["EDUCYRS"].max()
    education_stats = f"{education_mean:.2f} ({education_std:.2f}) ({education_min:.2f}, {education_max:.2f})"
   
   
    #COGNITIVE MARKERS (MOCA, GDS, UPSIT, REM, LNS, SDMT, JLO, INMEDIATE, HVLTRDLY, SFT, ADL, SCOPA)
    moca_mean = filtered_df["moca"].mean()
    moca_std = filtered_df["moca"].std()
    moca_min = filtered_df["moca"].min()
    moca_max = filtered_df["moca"].max()
    moca_stats = f"{moca_mean:.2f} ({moca_std:.2f}) ({moca_min:.2f}, {moca_max:.2f})"
    
    GDS_mean = filtered_df["gds"].mean()
    GDS_std = filtered_df["gds"].std()
    GDS_min = filtered_df["gds"].min()
    GDS_max = filtered_df["gds"].max()
    GDS_stats = f"{GDS_mean:.2f} ({GDS_std:.2f}) ({GDS_min:.2f}, {GDS_max:.2f})"
  
    UPSIT_mean = filtered_df["upsit"].mean()
    UPSIT_std = filtered_df["upsit"].std()
    UPSIT_min = filtered_df["upsit"].min()
    UPSIT_max = filtered_df["upsit"].max()
    UPSIT_stats = f"{UPSIT_mean:.2f} ({UPSIT_std:.2f}) ({UPSIT_min:.2f}, {UPSIT_max:.2f})"
  
    REM_mean = filtered_df["rem"].mean()
    REM_std = filtered_df["rem"].std()
    REM_min = filtered_df["rem"].min()
    REM_max = filtered_df["rem"].max()
    REM_stats = f"{REM_mean:.2f} ({REM_std:.2f}) ({REM_min:.2f}, {REM_max:.2f})"
  
    LNS_mean = filtered_df["lns"].mean()
    LNS_std = filtered_df["lns"].std()
    LNS_min = filtered_df["lns"].min()
    LNS_max = filtered_df["lns"].max()
    LNS_stats = f"{LNS_mean:.2f} ({LNS_std:.2f}) ({LNS_min:.2f}, {LNS_max:.2f})"
  
    SDMT_mean = filtered_df["SDMTOTAL"].mean()
    SDMT_std = filtered_df["SDMTOTAL"].std()
    SDMT_min = filtered_df["SDMTOTAL"].min()
    SDMT_max = filtered_df["SDMTOTAL"].max()
    SDMT_stats = f"{SDMT_mean:.2f} ({SDMT_std:.2f}) ({SDMT_min:.2f}, {SDMT_max:.2f})"
  
    JLO_mean = filtered_df["bjlot"].mean()
    JLO_std = filtered_df["bjlot"].std()
    JLO_min = filtered_df["bjlot"].min()
    JLO_max = filtered_df["bjlot"].max()
    JLO_stats = f"{JLO_mean:.2f} ({JLO_std:.2f}) ({JLO_min:.2f}, {JLO_max:.2f})"
    
    INMEDIATE_mean = filtered_df["hvlt_immediaterecall"].mean()
    INMEDIATE_std = filtered_df["hvlt_immediaterecall"].std()
    INMEDIATE_min = filtered_df["hvlt_immediaterecall"].min()
    INMEDIATE_max = filtered_df["hvlt_immediaterecall"].max()
    INMEDIATE_stats = f"{INMEDIATE_mean:.2f} ({INMEDIATE_std:.2f}) ({INMEDIATE_min:.2f}, {INMEDIATE_max:.2f})"
    
    HVLTRDLY_mean = filtered_df["HVLTRDLY"].mean()
    HVLTRDLY_std = filtered_df["HVLTRDLY"].std()
    HVLTRDLY_min = filtered_df["HVLTRDLY"].min()
    HVLTRDLY_max = filtered_df["HVLTRDLY"].max()
    HVLTRDLY_stats = f"{HVLTRDLY_mean:.2f} ({HVLTRDLY_std:.2f}) ({HVLTRDLY_min:.2f}, {HVLTRDLY_max:.2f})"
    
    SFT_mean = filtered_df["sft"].mean()
    SFT_std = filtered_df["sft"].std()
    SFT_min = filtered_df["sft"].min()
    SFT_max = filtered_df["sft"].max()
    SFT_stats = f"{SFT_mean:.2f} ({SFT_std:.2f}) ({SFT_min:.2f}, {SFT_max:.2f})"
    
    ADL_mean = filtered_df["MSEADLG"].mean()
    ADL_std = filtered_df["MSEADLG"].std()
    ADL_min = filtered_df["MSEADLG"].min()
    ADL_max = filtered_df["MSEADLG"].max()
    ADL_stats = f"{ADL_mean:.2f} ({ADL_std:.2f}) ({ADL_min:.2f}, {ADL_max:.2f})"
    
    SCOPA_mean = filtered_df["scopa"].mean()
    SCOPA_std = filtered_df["scopa"].std()
    SCOPA_min = filtered_df["scopa"].min()
    SCOPA_max = filtered_df["scopa"].max()
    SCOPA_stats = f"{SCOPA_mean:.2f} ({SCOPA_std:.2f}) ({SCOPA_min:.2f}, {SCOPA_max:.2f})"
    
    
    # DAT imaging (MEANPUT, MEANCAU)
    MEANPUT_mean = filtered_df["mean_putamen"].mean()
    MEANPUT_std = filtered_df["mean_putamen"].std()
    MEANPUT_min = filtered_df["mean_putamen"].min()
    MEANPUT_max = filtered_df["mean_putamen"].max()
    MEANPUT_stats = f"{MEANPUT_mean:.2f} ({MEANPUT_std:.2f}) ({MEANPUT_min:.2f}, {MEANPUT_max:.2f})"

    MEANCAU_mean = filtered_df["mean_caudate"].mean()
    MEANCAU_std = filtered_df["mean_caudate"].std()
    MEANCAU_min = filtered_df["mean_caudate"].min()
    MEANCAU_max = filtered_df["mean_caudate"].max()
    MEANCAU_stats = f"{MEANCAU_mean:.2f} ({MEANCAU_std:.2f}) ({MEANCAU_min:.2f}, {MEANCAU_max:.2f})"
    
    
    # CSF (ABETA, ASYN, TAU, PTAU, pTauAB)
    ABETA_mean = filtered_df["abeta"].mean()
    ABETA_std = filtered_df["abeta"].std()
    ABETA_min = filtered_df["abeta"].min()
    ABETA_max = filtered_df["abeta"].max()
    ABETA_stats = f"{ABETA_mean:.2f} ({ABETA_std:.2f}) ({ABETA_min:.2f}, {ABETA_max:.2f})"

    ASYN_mean = filtered_df["asyn"].mean()
    ASYN_std = filtered_df["asyn"].std()
    ASYN_min = filtered_df["asyn"].min()
    ASYN_max = filtered_df["asyn"].max()
    ASYN_stats = f"{ASYN_mean:.2f} ({ASYN_std:.2f}) ({ASYN_min:.2f}, {ASYN_max:.2f})"
    
    TAU_mean = filtered_df["tau"].mean()
    TAU_std = filtered_df["tau"].std()
    TAU_min = filtered_df["tau"].min()
    TAU_max = filtered_df["tau"].max()
    TAU_stats = f"{TAU_mean:.2f} ({TAU_std:.2f}) ({TAU_min:.2f}, {TAU_max:.2f})"

    PTAU_mean = filtered_df["ptau"].mean()
    PTAU_std = filtered_df["ptau"].std()
    PTAU_min = filtered_df["ptau"].min()
    PTAU_max = filtered_df["ptau"].max()
    PTAU_stats = f"{PTAU_mean:.2f} ({PTAU_std:.2f}) ({PTAU_min:.2f}, {PTAU_max:.2f})"
    
    pTauAB_mean = filtered_df["ptau_ab"].mean()
    pTauAB_std = filtered_df["ptau_ab"].std()
    pTauAB_min = filtered_df["ptau_ab"].min()
    pTauAB_max = filtered_df["ptau_ab"].max()
    pTauAB_stats = f"{pTauAB_mean:.2f} ({pTauAB_std:.2f}) ({pTauAB_min:.2f}, {pTauAB_max:.2f})"


    # MOTOR (UPDRSTOT, UPDRSTOTON, UPDRS1, UPDRS2, UPDRS3, UPDRS3ON)
    UPDRSTOT_mean = filtered_df["updrs_totscore"].mean()
    UPDRSTOT_std = filtered_df["updrs_totscore"].std()
    UPDRSTOT_min = filtered_df["updrs_totscore"].min()
    UPDRSTOT_max = filtered_df["updrs_totscore"].max()
    UPDRSTOT_stats = f"{UPDRSTOT_mean:.2f} ({UPDRSTOT_std:.2f}) ({UPDRSTOT_min:.2f}, {UPDRSTOT_max:.2f})"

    UPDRSTOTON_mean = filtered_df["updrs_totscore_on"].mean()
    UPDRSTOTON_std = filtered_df["updrs_totscore_on"].std()
    UPDRSTOTON_min = filtered_df["updrs_totscore_on"].min()
    UPDRSTOTON_max = filtered_df["updrs_totscore_on"].max()
    UPDRSTOTON_stats = f"{UPDRSTOTON_mean:.2f} ({UPDRSTOTON_std:.2f}) ({UPDRSTOTON_min:.2f}, {UPDRSTOTON_max:.2f})"

    UPDRS1_mean = filtered_df["updrs1_score"].mean()
    UPDRS1_std = filtered_df["updrs1_score"].std()
    UPDRS1_min = filtered_df["updrs1_score"].min()
    UPDRS1_max = filtered_df["updrs1_score"].max()
    UPDRS1_stats = f"{UPDRS1_mean:.2f} ({UPDRS1_std:.2f}) ({UPDRS1_min:.2f}, {UPDRS1_max:.2f})"
    
    UPDRS2_mean = filtered_df["updrs2_score"].mean()
    UPDRS2_std = filtered_df["updrs2_score"].std()
    UPDRS2_min = filtered_df["updrs2_score"].min()
    UPDRS2_max = filtered_df["updrs2_score"].max()
    UPDRS2_stats = f"{UPDRS2_mean:.2f} ({UPDRS2_std:.2f}) ({UPDRS2_min:.2f}, {UPDRS2_max:.2f})"

    UPDRS3_mean = filtered_df["updrs3_score"].mean()
    UPDRS3_std = filtered_df["updrs3_score"].std()
    UPDRS3_min = filtered_df["updrs3_score"].min()
    UPDRS3_max = filtered_df["updrs3_score"].max()
    UPDRS3_stats = f"{UPDRS3_mean:.2f} ({UPDRS3_std:.2f}) ({UPDRS3_min:.2f}, {UPDRS3_max:.2f})"
    
    UPDRS3ON_mean = filtered_df["updrs3_score_on"].mean()
    UPDRS3ON_std = filtered_df["updrs3_score_on"].std()
    UPDRS3ON_min = filtered_df["updrs3_score_on"].min()
    UPDRS3ON_max = filtered_df["updrs3_score_on"].max()
    UPDRS3ON_stats = f"{UPDRS3ON_mean:.2f} ({UPDRS3ON_std:.2f}) ({UPDRS3ON_min:.2f}, {UPDRS3ON_max:.2f})"
    
    data_nm[dx_category]=[f"{filtered_subjects} ({filtered_subjects_percentage})", f"{female_subjects} ({female_percentage})", f"{APOE_e4_subjects} ({APOE_e4_percentage}) n={APOE_e4_n}", age_stats, education_stats, GDS_stats, UPSIT_stats, REM_stats, UPDRS3_stats, UPDRSTOT_stats, UPDRSTOTON_stats, UPDRS1_stats, UPDRS2_stats,  UPDRS3ON_stats, moca_stats, LNS_stats, SDMT_stats, JLO_stats, INMEDIATE_stats, HVLTRDLY_stats, SFT_stats, ADL_stats, SCOPA_stats, ABETA_stats, ASYN_stats, TAU_stats, PTAU_stats, pTauAB_stats, MEANPUT_stats, MEANCAU_stats]
    

# In[53]:


#Group1 : PD, Group2 : HC
#PD to HC (a)

def one_way_anova_with_posthoc(group1, group2):
    # Perform one-way ANOVA
    f_value, p_value = f_oneway(group1, group2)
    print(p_value)
    # Check if p-value is less than 0.01
    if p_value < 0.01:
        # Perform Tukey post hoc test
        data = np.concatenate([group1, group2])
        labels = ['group1'] * len(group1) + ['group2'] * len(group2)
        tukey_results = pairwise_tukeyhsd(data, labels, 0.01)
        possible_results = ['a','b','c','d','e','f']
        post_hoc = [res for res,reject in zip(possible_results,tukey_results.reject) if reject == True]
        post_hoc = ",".join(post_hoc)
        return post_hoc


# In[54]:


#Group1 : PD, Group2 : HC
#PD to HC (a)
def chi_square_with_posthoc(group1, group2, contingency_table):
    # Perform chi-square test
    chi2, p, dof, expected = chi2_contingency(contingency_table)

    # Perform post-hoc test if p-value is significant
    if p < 0.01:
        data = np.concatenate([group1, group2])
        labels = ['group1'] * len(group1) + ['group2'] * len(group2)
        tukey_results = pairwise_tukeyhsd(data, labels, 0.01)
        possible_results = ['a','b','c','d','e','f']
        post_hoc = [res for res,reject in zip(possible_results,tukey_results.reject) if reject == True]
        post_hoc = ",".join(post_hoc)
        return post_hoc


# In[55]:


filtered_nm_PD = df[(df["APPRDX"]==1) & (df["YEAR"] == 0)]
filtered_nm_HC = df[(df["APPRDX"]==2) & (df["YEAR"] == 0)]


data_nm["Post-Hoc"] = [""]*len(data_nm["Group"])

# In[56]:

group1_nm = filtered_nm_PD["gen"].dropna()
group2_nm = filtered_nm_HC["gen"].dropna()


# Convert data to contingency table format
contingency_table_nm = np.array([
    [np.sum(group1_nm == 2), np.sum(group1_nm == 1)],
    [np.sum(group2_nm == 2), np.sum(group2_nm == 1)]
])

data_nm["Post-Hoc"][data_nm["Group"].index("Female")] = chi_square_with_posthoc(group1_nm, group2_nm, contingency_table_nm)

# In[57]:


#APOE4
group1_nm = filtered_nm_PD["APOE_e4"].dropna()
group2_nm = filtered_nm_HC["APOE_e4"].dropna()


# Convert data to contingency table format
contingency_table_nm = np.array([
    [np.sum(group1_nm == 0), np.sum(group1_nm == 1), np.sum(group1_nm == 2)],
    [np.sum(group2_nm == 0), np.sum(group2_nm == 1), np.sum(group1_nm == 2)]
])

data_nm["Post-Hoc"][data_nm["Group"].index("APOE4")] = chi_square_with_posthoc(group1_nm, group2_nm,contingency_table_nm)


# In[58]:
    
# data_nm["Group"]=["Subjects","Female","APOE4","Age","Education", "GDS","UPSIT","REM","UPDRS3", "UPDRSTOT","UPDRSTOTOM","UPDRS1","UPDRS2","UPDRS3ON","MOCA","LNS","SDMT","JLO","INMEDIATE","HVLTRDLY","SFT","ADL","SCOPA", "ABETA", "ASYN", "TAU","PTAU", "pTauAB",  "MEANPUT","MEANCAU"]
variables = ["age", "EDUCYRS", "gds", "upsit", "rem", "updrs3_score", "updrs_totscore","updrs_totscore_on", "updrs1_score", "updrs2_score", "updrs3_score_on", "moca","lns","SDMTOTAL","bjlot","hvlt_immediaterecall","HVLTRDLY","sft","MSEADLG","scopa","abeta","asyn","tau","ptau","ptau_ab","mean_putamen","mean_caudate"]
    
for i, v in enumerate(variables):
    group1_nm = filtered_nm_PD[v].dropna()
    group2_nm = filtered_nm_HC[v].dropna()

    data_nm["Post-Hoc"][i+3] = one_way_anova_with_posthoc(group1_nm, group2_nm)


# In[59]:

#Display table (and latex format)
table_nm = pd.DataFrame(data_nm)
latex_table = table_nm.to_latex(index=False)
print(latex_table)
table_nm = table_nm.style.hide(axis="index")
#display(table_nm)




# In[60]:

#AGE
#group1_nm = filtered_nm_PD["age"].dropna()
#group2_nm = filtered_nm_HC["age"].dropna()


#data_nm["Post-Hoc"][data_nm["Group"].index("Age")] = one_way_anova_with_posthoc(group1_nm, group2_nm)

