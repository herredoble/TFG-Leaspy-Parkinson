# -*- coding: utf-8 -*-
"""
Created on Thu Sep 14 17:57:09 2023

@author: rroca
"""
#In[50]:
import pandas as pd
import scipy.stats as stats
#import tabulate as tabulate
#from tabulate import tabulate
import numpy as np
from scipy.stats import f_oneway, ttest_ind, chi2_contingency
from statsmodels.stats.multicomp import pairwise_tukeyhsd
#import regex as re
#from datetime import datetime



#file_xlsx = './data/PPMI_Original_Cohort_BL_to_Year_5_Dataset_Apr2020.xlsx'
#file_csv = './data/PPMI_Original_Cohort_BL_to_Year_5_Dataset_Apr2020.csv'
file_csv ="./data/Dataset_Apr2020.csv"

#df=pd.read_excel(file_xlsx)
df=pd.read_csv(file_csv)


#print(df)


df_PD=df.loc[(df['APPRDX']==1)] #SELECCIONA PD
df_PD=df_PD.reset_index(drop=True)


#In[51]:
     #Guardar en ID_SinCog los pacientes con cogstate todo NAN
def fill_cogstate_with_NAN(df):
   
    ID=df["PATNO"].unique()
    ID_sinCog = np.full(len(ID), np.nan)
    
    for i in range(len(ID)):
        cogstate_subj=df.loc[df["PATNO"]==ID[i], 'cogstate']
        #mask_cog = np.full_like(cogstate_subj, True)
        #mask_cog[np.isnan(cogstate_subj)] = False
        mask_cog = ~np.isnan(cogstate_subj)
        if np.sum(mask_cog) == 0:
            ID_sinCog[i] = ID[i]
            
    ID_sinCog = ID_sinCog[~np.isnan(ID_sinCog)]
    
    # ....
    #cogstate_est=df["cogstate"]
    for i in range(len(ID_sinCog)):
        
        
        mask_subj=df["PATNO"]==ID_sinCog[i]
        MCI_test_subj=(df.loc[mask_subj==True, 'MCI_testscores'])+1
        NP1COG=df.loc[mask_subj==True, 'NP1COG']
        NP1COG_subj=(NP1COG>1)+1

        
        cog_subj = np.full(np.sum(mask_subj), np.nan)
        mask_MCI_test = ~np.isnan(MCI_test_subj)
        mask_NP1COG = ~np.isnan(NP1COG_subj)             ###CAMBIA DE REPENTE???? EN i = 10

        
        mask_equal_criteria = np.logical_and(MCI_test_subj == NP1COG_subj, mask_MCI_test, mask_NP1COG)
        if np.sum(mask_equal_criteria) > 0:
            cog_subj[mask_equal_criteria] = MCI_test_subj[mask_equal_criteria]
        else:
            MCI_ = MCI_test_subj[mask_MCI_test]
            NPI_ = NP1COG_subj[mask_NP1COG]
            idx = np.where(mask_NP1COG)[0]
            if len(idx)>0:
                cog_subj[idx[0]] = min(MCI_[0], NPI_[0])
                cog_subj[idx[-1]] = min(MCI_[-1], NPI_[-1])

        #cogstate_est[mask_subj] = cog_subj
        df.loc[mask_subj, 'cogstate'] = cog_subj
        
   # df["cogstate"]=cogstate_est
    cogstate_interp=df["cogstate"].copy()
    
    ID=df["PATNO"].unique()
    ID_sinCog=[]
    
    return cogstate_interp, ID_sinCog
    
    
        

    
        
#In [52]:
#convertTime_PPMI

def convertTime_PPMI(PPMI):
    unique_ID = PPMI["PATNO"].unique()

    # Convert arrays to DataFrame for proper indexing and assignment
    cogstate = pd.Series(np.full(len(PPMI), np.nan), name='cogstate')
    MCI_testscores = pd.Series(np.full(len(PPMI), np.nan), name='MCI_testscores')
    np1cog = pd.Series(np.full(len(PPMI), np.nan), name='np1cog')

    convertTimeCogstate = pd.Series(np.full(len(PPMI), np.nan), name='convertTimeCogstate')
    convertTimeMCI_test = pd.Series(np.full(len(PPMI), np.nan), name='convertTimeMCI_test')
    convertTimeNp1cog = pd.Series(np.full(len(PPMI), np.nan), name='convertTimeNp1cog')

    ID_sinCog = []
    

    for i in range(len(unique_ID)):
    #j=[2224, 2225, 2226]
    #for i in j:
        index = PPMI.index[PPMI['PATNO'] == unique_ID[i]]

        PD_subj = PPMI.loc[index]
        cogstate_subj = PD_subj['cogstate']
        MCI_testscores_subj = PD_subj['MCI_testscores']
        np1cog_subj = PD_subj['NP1COG']
        year_subj = PD_subj['YEAR']

        # Criteria cogstate: 1(HC),2(MCI), 3(Dementia)
        year_cog = year_subj[~np.isnan(cogstate_subj)]
        cogstate_subj = cogstate_subj[~np.isnan(cogstate_subj)]
        if len(cogstate_subj) > 0:
            cogstate.loc[index] = cogstate_subj.iloc[-1]
            if cogstate_subj.iloc[-1] > 1:
                convertTimeCogstate.loc[index] = np.tile(min(year_cog[cogstate_subj > 1]), len(index))
            else:
                convertTimeCogstate.loc[index] = np.tile(max(year_cog), len(index))
        else:
            ID_sinCog.append((1, unique_ID[i]))

        # Criteria MCI_testscores: 0 (HC), 1(MCI)
        year_MCI = year_subj[~np.isnan(MCI_testscores_subj)]
        MCI_testscores_subj = MCI_testscores_subj[~np.isnan(MCI_testscores_subj)]
        if len(MCI_testscores_subj) > 0:
            MCI_testscores.loc[index] = MCI_testscores_subj.iloc[-1]
            if MCI_testscores_subj.iloc[-1] > 0:
                convertTimeMCI_test.loc[index] = np.tile(min(year_MCI[MCI_testscores_subj > 0]), len(index))
            else:
                convertTimeMCI_test.loc[index] = np.tile(max(year_MCI), len(index))
        else:
            print(f"Subject {unique_ID[i]} without MCI testscores data")
            ID_sinCog.append((2, unique_ID[i]))

        # Criteria np1cog: 0 (HC), 1(Slight), 2(Mild), 3 (Moderate), 4(Severate)
        year_cog = year_subj[~np.isnan(np1cog_subj)]
        np1cog_subj = np1cog_subj[~np.isnan(np1cog_subj)]
        if len(np1cog_subj) > 0:
            np1cog.loc[index] = np1cog_subj.iloc[-1]
            if np1cog_subj.iloc[-1] > 1:
                convertTimeNp1cog.loc[index] = np.tile(min(year_cog[np1cog_subj > 1]), len(index))
            else:
                convertTimeNp1cog.loc[index] = np.tile(max(year_cog), len(index))
        else:
            print(f"Subject {unique_ID[i]} without np1cog data")
            ID_sinCog.append((3, unique_ID[i]))


    print (ID_sinCog)
    print (len(ID_sinCog))
    ID_sinCog = [tupla[1] for tupla in ID_sinCog]
    
    for i in range(len(ID_sinCog)):
        mask_subj=PPMI["PATNO"]==ID_sinCog[i]
        MCI_test_subj=(PPMI.loc[mask_subj==True, 'MCI_testscores'])+1
        NP1COG_subj=PPMI.loc[mask_subj==True, 'NP1COG']
        cog_subj = (PPMI.loc[mask_subj==True, 'cogstate'])
        
        if NP1COG_subj.isna().any():
            ultimo_valor_no_nan = NP1COG_subj.dropna().iloc[-1]
            NP1COG_subj.fillna(ultimo_valor_no_nan, inplace=True)
            
        mask_NP1COG = ~np.isnan(NP1COG_subj)
        if np.sum(mask_NP1COG) > 0:
            cog_subj[mask_NP1COG] = NP1COG_subj[mask_NP1COG]+1
        else:
            print("ERROR PASANDO DATOS")
            
        index = PPMI.index[PPMI['PATNO'] == ID_sinCog[i]]
        cogstate.loc[index] = cog_subj.iloc[-1]

    
        
    PPMI['cogstate_end'] = cogstate
    PPMI['MCI_testscores_end'] = MCI_testscores
    PPMI['np1cog_end'] = np1cog

    PPMI['convertTimeCogstate'] = convertTimeCogstate
    PPMI['convertTimeMCI_test'] = convertTimeMCI_test
    PPMI['convertTimeNp1cog'] = convertTimeNp1cog

    return PPMI, ID_sinCog


#In[55]:
cogstate_interp, ID_sinCog = fill_cogstate_with_NAN(df_PD)
cogstate_interp_float = cogstate_interp.astype(float)
#df_PD.loc[:, 'cogstate'] = (cogstate_interp_float)
df_PD['cogstate'] = cogstate_interp_float
df_PD, ID_sinCog = convertTime_PPMI(df_PD)
    
    
 # Encuentra la última visita para cada paciente
#df_ult = df_PD.groupby('PATNO').min().reset_index()
df_ult=df_PD[df_PD["YEAR"] == 0]

#NM subjects????    
data_nm={}
data_nm["Group"]=["Subjects","Female","APOE4","Age","Education", "GDS","UPSIT","REM","UPDRS3","MOCA","LNS","SDMT","JLO","INMEDIATE","HVLTRDLY","SFT","ADL","SCOPA", "ABETA", "ASYN", "TAU","PTAU", "pTauAB",  "MEANPUT","MEANCAU"]

        
for dx_category in ["PD_CU", "PD_MCI", "PD_DEMENTIA"]:
    #first filtering by group
    if dx_category=="PD_CU":
        filtered_df=df_ult[(df_ult["cogstate_end"]==1)]
        df_PDCU=filtered_df.copy()
    elif dx_category=="PD_MCI":
        filtered_df=df_ult[(df_ult["cogstate_end"]==2)]
        df_PDMCI=filtered_df.copy()
    else:
        filtered_df=df_ult[(df_ult["cogstate_end"]==3)]
        df_PDD=filtered_df.copy()
    

    #SUBJECTS
    filtered_subjects=filtered_df["PATNO"].nunique()
    subjects=df["PATNO"].nunique()
    filtered_subjects_percentage = f"{(filtered_subjects/subjects)*100:.1f}%"
    
    #FEMALE
    female_subjects = filtered_df[filtered_df["gen"] == 2]["PATNO"].nunique()
    female_percentage = f"{(female_subjects/filtered_subjects)*100:.1f}%"
   
    #APOE4
    APOE_e4_subjects = filtered_df[filtered_df["APOE_e4"] > 0]["PATNO"].nunique()
    APOE_e4_n = filtered_df[(filtered_df["APOE_e4"] >=0) & (filtered_df["APOE_e4"]<=2)]["PATNO"].nunique()
    APOE_e4_percentage = f"{(APOE_e4_subjects/APOE_e4_n)*100:.1f}%"
    
    #AGE
    age_mean = filtered_df["age"].mean()
    age_std = filtered_df["age"].std()
    age_min = filtered_df["age"].min()
    age_max = filtered_df["age"].max()
    age_stats = f"{age_mean:.1f} ({age_std:.1f}) ({age_min:.1f}, {age_max:.1f})"
    
    #EDUCATION
    education_mean = filtered_df["EDUCYRS"].mean()
    education_std = filtered_df["EDUCYRS"].std()
    education_min = filtered_df["EDUCYRS"].min()
    education_max = filtered_df["EDUCYRS"].max()
    education_stats = f"{education_mean:.2f} ({education_std:.2f}) ({education_min:.2f}, {education_max:.2f})"
   
   
    #COGNITIVE MARKERS (MOCA, GDS, UPSIT, REM, LNS, SDMT, JLO, INMEDIATE, HVLTRDLY, SFT, ADL, SCOPA)
    moca_mean = filtered_df["moca"].mean()
    moca_std = filtered_df["moca"].std()
    moca_min = filtered_df["moca"].min()
    moca_max = filtered_df["moca"].max()
    moca_stats = f"{moca_mean:.2f} ({moca_std:.2f}) ({moca_min:.2f}, {moca_max:.2f})"
    
    GDS_mean = filtered_df["gds"].mean()
    GDS_std = filtered_df["gds"].std()
    GDS_min = filtered_df["gds"].min()
    GDS_max = filtered_df["gds"].max()
    GDS_stats = f"{GDS_mean:.2f} ({GDS_std:.2f}) ({GDS_min:.2f}, {GDS_max:.2f})"
  
    UPSIT_mean = filtered_df["upsit"].mean()
    UPSIT_std = filtered_df["upsit"].std()
    UPSIT_min = filtered_df["upsit"].min()
    UPSIT_max = filtered_df["upsit"].max()
    UPSIT_stats = f"{UPSIT_mean:.2f} ({UPSIT_std:.2f}) ({UPSIT_min:.2f}, {UPSIT_max:.2f})"
  
    REM_mean = filtered_df["rem"].mean()
    REM_std = filtered_df["rem"].std()
    REM_min = filtered_df["rem"].min()
    REM_max = filtered_df["rem"].max()
    REM_stats = f"{REM_mean:.2f} ({REM_std:.2f}) ({REM_min:.2f}, {REM_max:.2f})"
  
    LNS_mean = filtered_df["lns"].mean()
    LNS_std = filtered_df["lns"].std()
    LNS_min = filtered_df["lns"].min()
    LNS_max = filtered_df["lns"].max()
    LNS_stats = f"{LNS_mean:.2f} ({LNS_std:.2f}) ({LNS_min:.2f}, {LNS_max:.2f})"
  
    SDMT_mean = filtered_df["SDMTOTAL"].mean()
    SDMT_std = filtered_df["SDMTOTAL"].std()
    SDMT_min = filtered_df["SDMTOTAL"].min()
    SDMT_max = filtered_df["SDMTOTAL"].max()
    SDMT_stats = f"{SDMT_mean:.2f} ({SDMT_std:.2f}) ({SDMT_min:.2f}, {SDMT_max:.2f})"
  
    JLO_mean = filtered_df["bjlot"].mean()
    JLO_std = filtered_df["bjlot"].std()
    JLO_min = filtered_df["bjlot"].min()
    JLO_max = filtered_df["bjlot"].max()
    JLO_stats = f"{JLO_mean:.2f} ({JLO_std:.2f}) ({JLO_min:.2f}, {JLO_max:.2f})"
    
    INMEDIATE_mean = filtered_df["hvlt_immediaterecall"].mean()
    INMEDIATE_std = filtered_df["hvlt_immediaterecall"].std()
    INMEDIATE_min = filtered_df["hvlt_immediaterecall"].min()
    INMEDIATE_max = filtered_df["hvlt_immediaterecall"].max()
    INMEDIATE_stats = f"{INMEDIATE_mean:.2f} ({INMEDIATE_std:.2f}) ({INMEDIATE_min:.2f}, {INMEDIATE_max:.2f})"
    
    HVLTRDLY_mean = filtered_df["HVLTRDLY"].mean()
    HVLTRDLY_std = filtered_df["HVLTRDLY"].std()
    HVLTRDLY_min = filtered_df["HVLTRDLY"].min()
    HVLTRDLY_max = filtered_df["HVLTRDLY"].max()
    HVLTRDLY_stats = f"{HVLTRDLY_mean:.2f} ({HVLTRDLY_std:.2f}) ({HVLTRDLY_min:.2f}, {HVLTRDLY_max:.2f})"
    
    SFT_mean = filtered_df["sft"].mean()
    SFT_std = filtered_df["sft"].std()
    SFT_min = filtered_df["sft"].min()
    SFT_max = filtered_df["sft"].max()
    SFT_stats = f"{SFT_mean:.2f} ({SFT_std:.2f}) ({SFT_min:.2f}, {SFT_max:.2f})"
    
    ADL_mean = filtered_df["MSEADLG"].mean()
    ADL_std = filtered_df["MSEADLG"].std()
    ADL_min = filtered_df["MSEADLG"].min()
    ADL_max = filtered_df["MSEADLG"].max()
    ADL_stats = f"{ADL_mean:.2f} ({ADL_std:.2f}) ({ADL_min:.2f}, {ADL_max:.2f})"
    
    SCOPA_mean = filtered_df["scopa"].mean()
    SCOPA_std = filtered_df["scopa"].std()
    SCOPA_min = filtered_df["scopa"].min()
    SCOPA_max = filtered_df["scopa"].max()
    SCOPA_stats = f"{SCOPA_mean:.2f} ({SCOPA_std:.2f}) ({SCOPA_min:.2f}, {SCOPA_max:.2f})"
    
    
    # DAT imaging (MEANPUT, MEANCAU)
    MEANPUT_mean = filtered_df["mean_putamen"].mean()
    MEANPUT_std = filtered_df["mean_putamen"].std()
    MEANPUT_min = filtered_df["mean_putamen"].min()
    MEANPUT_max = filtered_df["mean_putamen"].max()
    MEANPUT_stats = f"{MEANPUT_mean:.2f} ({MEANPUT_std:.2f}) ({MEANPUT_min:.2f}, {MEANPUT_max:.2f})"

    MEANCAU_mean = filtered_df["mean_caudate"].mean()
    MEANCAU_std = filtered_df["mean_caudate"].std()
    MEANCAU_min = filtered_df["mean_caudate"].min()
    MEANCAU_max = filtered_df["mean_caudate"].max()
    MEANCAU_stats = f"{MEANCAU_mean:.2f} ({MEANCAU_std:.2f}) ({MEANCAU_min:.2f}, {MEANCAU_max:.2f})"
    
    
    # CSF (ABETA, ASYN, TAU, PTAU, pTauAB)
    ABETA_mean = filtered_df["abeta"].mean()
    ABETA_std = filtered_df["abeta"].std()
    ABETA_min = filtered_df["abeta"].min()
    ABETA_max = filtered_df["abeta"].max()
    ABETA_stats = f"{ABETA_mean:.2f} ({ABETA_std:.2f}) ({ABETA_min:.2f}, {ABETA_max:.2f})"

    ASYN_mean = filtered_df["asyn"].mean()
    ASYN_std = filtered_df["asyn"].std()
    ASYN_min = filtered_df["asyn"].min()
    ASYN_max = filtered_df["asyn"].max()
    ASYN_stats = f"{ASYN_mean:.2f} ({ASYN_std:.2f}) ({ASYN_min:.2f}, {ASYN_max:.2f})"
    
    TAU_mean = filtered_df["tau"].mean()
    TAU_std = filtered_df["tau"].std()
    TAU_min = filtered_df["tau"].min()
    TAU_max = filtered_df["tau"].max()
    TAU_stats = f"{TAU_mean:.2f} ({TAU_std:.2f}) ({TAU_min:.2f}, {TAU_max:.2f})"

    PTAU_mean = filtered_df["ptau"].mean()
    PTAU_std = filtered_df["ptau"].std()
    PTAU_min = filtered_df["ptau"].min()
    PTAU_max = filtered_df["ptau"].max()
    PTAU_stats = f"{PTAU_mean:.2f} ({PTAU_std:.2f}) ({PTAU_min:.2f}, {PTAU_max:.2f})"
    
    pTauAB_mean = filtered_df["ptau_ab"].mean()
    pTauAB_std = filtered_df["ptau_ab"].std()
    pTauAB_min = filtered_df["ptau_ab"].min()
    pTauAB_max = filtered_df["ptau_ab"].max()
    pTauAB_stats = f"{pTauAB_mean:.4f} ({pTauAB_std:.4f}) ({pTauAB_min:.4f}, {pTauAB_max:.4f})"


    # MOTOR (UPDRSTOT, UPDRSTOTON, UPDRS1, UPDRS2, UPDRS3, UPDRS3ON)

    UPDRS3_mean = filtered_df["updrs3_score"].mean()
    UPDRS3_std = filtered_df["updrs3_score"].std()
    UPDRS3_min = filtered_df["updrs3_score"].min()
    UPDRS3_max = filtered_df["updrs3_score"].max()
    UPDRS3_stats = f"{UPDRS3_mean:.2f} ({UPDRS3_std:.2f}) ({UPDRS3_min:.2f}, {UPDRS3_max:.2f})"

    data_nm[dx_category]=[f"{filtered_subjects} ({filtered_subjects_percentage})", f"{female_subjects} ({female_percentage})", f"{APOE_e4_subjects} ({APOE_e4_percentage}) n={APOE_e4_n}", age_stats, education_stats, GDS_stats, UPSIT_stats, REM_stats, UPDRS3_stats, moca_stats, LNS_stats, SDMT_stats, JLO_stats, INMEDIATE_stats, HVLTRDLY_stats, SFT_stats, ADL_stats, SCOPA_stats, ABETA_stats, ASYN_stats, TAU_stats, PTAU_stats, pTauAB_stats, MEANPUT_stats, MEANCAU_stats]
    

# In[56]:


#Group1 : PD_CU, Group2 : PD_MCI, Group3 : PD_DEMENTIA
#PD_CU to PD_MCI (a)
#PD_CU  to PD_DEMENTIA (b)
#PD_MCI to PD_DEMENTIA (c)

def one_way_anova_with_posthoc(group1, group2, group3, i, v):
    # Perform one-way ANOVA
    f_value, p_value = f_oneway(group1, group2, group3)
    print(p_value)
    
    #data_nm["p-value"][i+3]=p_value
    
    # Check if p-value is less than 0.01
    if p_value < 0.01:
        # Perform Tukey post hoc test
        data = np.concatenate([group1, group2, group3])
        labels = ['group1'] * len(group1) + ['group2'] * len(group2)+['group3'] * len(group3)
        tukey_results = pairwise_tukeyhsd(data, labels, 0.01)
        possible_results = ['a','b','c','d','e','f']
        post_hoc = [res for res,reject in zip(possible_results,tukey_results.reject) if reject == True]
        post_hoc = ",".join(post_hoc)
                
        if p_value<0.001:
            data_nm["p-value"][i+3]=f"$<$ 0.001"
        else:
            data_nm["p-value"][i+3]= f"{p_value:.3f}"
        
        return post_hoc
    
    else:
        data_nm["p-value"][i+3]= f"{p_value:.3f}"
        
        


# In[57]:


#Group1 : PD_CU, Group2 : PD_MCI, Group3 : PD_DEMENTIA
#PD_CU to PD_MCI (a)
#PD_CU  to PD_DEMENTIA (b)
#PD_MCI to PD_DEMENTIA (c)
 
def chi_square_with_posthoc(group1, group2, group3, contingency_table, i, v):
    # Perform chi-square test
    chi2, p, dof, expected = chi2_contingency(contingency_table)
    print(p)
    
    #data_nm["p-value"][i+1]=p
    
    # Perform post-hoc test if p-value is significant
    if p < 0.01:
        data = np.concatenate([group1, group2, group3])
        labels = ['group1'] * len(group1) + ['group2'] * len(group2)+ ['group3'] * len(group3)
        tukey_results = pairwise_tukeyhsd(data, labels, 0.01)
        possible_results = ['a','b','c','d','e','f']
        post_hoc = [res for res,reject in zip(possible_results,tukey_results.reject) if reject == True]
        post_hoc = ",".join(post_hoc)
                
        if p<0.001:
            data_nm["p-value"][i+1]=f"$<$ 0.001"
        else:
            data_nm["p-value"][i+1]=f"{p:.3f}"
        
        return post_hoc
    
    else:
        data_nm["p-value"][i+1]=f"{p:.3f}"

# In[58]:

filtered_nm_PD_CU=df_PDCU
filtered_nm_PD_MCI=df_PDMCI
filtered_nm_PD_DEMENTIA=df_PDD

data_nm["p-value"]= [""]*len(data_nm["Group"])
data_nm["Post-Hoc"] = [""]*len(data_nm["Group"])


# In[59]:

variables = ["gen", "APOE_e4"]
     
for i, v in enumerate(variables):
    group1_nm = filtered_nm_PD_CU[v].dropna()
    group2_nm = filtered_nm_PD_MCI[v].dropna()
    group3_nm = filtered_nm_PD_DEMENTIA[v].dropna()
    
    if i==0:
        contingency_table_nm = np.array([
            [np.sum(group1_nm == 2), np.sum(group1_nm == 1)],
            [np.sum(group2_nm == 2), np.sum(group2_nm == 1)],
            [np.sum(group3_nm == 2), np.sum(group3_nm == 1)]
        ])
    else:
        contingency_table_nm = np.array([
            [np.sum(group1_nm == 0), np.sum(group1_nm == 1), np.sum(group1_nm == 2)],
            [np.sum(group2_nm == 0), np.sum(group2_nm == 1), np.sum(group1_nm == 2)],
            [np.sum(group3_nm == 0), np.sum(group3_nm == 1), np.sum(group3_nm == 2)]
        ])
    
    data_nm["Post-Hoc"][i+1] = chi_square_with_posthoc(group1_nm, group2_nm, group3_nm, contingency_table_nm, i, v)




# In[61]:
     
# data_nm["Group"]=["Subjects","Female","APOE4","Age","Education", "GDS","UPSIT","REM","UPDRS3", "UPDRSTOT","UPDRSTOTOM","UPDRS1","UPDRS2","UPDRS3ON","MOCA","LNS","SDMT","JLO","INMEDIATE","HVLTRDLY","SFT","ADL","SCOPA", "ABETA", "ASYN", "TAU","PTAU", "pTauAB",  "MEANPUT","MEANCAU"]
variables = ["age", "EDUCYRS", "gds", "upsit", "rem", "updrs3_score", "moca","lns","SDMTOTAL","bjlot","hvlt_immediaterecall","HVLTRDLY","sft","MSEADLG","scopa","abeta","asyn","tau","ptau","ptau_ab","mean_putamen","mean_caudate"]
     
for i, v in enumerate(variables):
    group1_nm = filtered_nm_PD_CU[v].dropna()
    group2_nm = filtered_nm_PD_MCI[v].dropna()
    group3_nm = filtered_nm_PD_DEMENTIA[v].dropna()

    data_nm["Post-Hoc"][i+3] = one_way_anova_with_posthoc(group1_nm, group2_nm, group3_nm, i, v)

  
# In[59]:

#Display table (and latex format)
table_nm = pd.DataFrame(data_nm)
latex_table = table_nm.to_latex(index=False)
print(latex_table)
table_nm = table_nm.style.hide(axis="index")
#display(table_nm)       


            
    
        

