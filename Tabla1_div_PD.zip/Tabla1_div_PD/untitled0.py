# -*- coding: utf-8 -*-
"""
Created on Thu Sep 14 17:57:09 2023

@author: rroca
"""

def Cognitive_groups(df): #se le pasa un dataframe con los PD
    ID=df["PATNO"].unique()
    
    cogstate = []
    MCI_testscores = []
    np1cog = []
    convertTimeCogstate = []
    convertTimeMCI_test = []
    convertTimeNp1cog = []
    ID_sinCog = []  
    
    for i in range(len(ID)):
        index = df[df["PATNO"] == ID[i]].index #indice visitas paciente
        PD_subj = df.iloc[index, :]  #dataframe visitas paciente
        
        cogstate_subj = PD_subj["cogstate"]  # 1(HC), 2(MCI), 3(Dementia)
        MCI_testscores_subj = PD_subj["MCI_testscores"]  # 0 (HC), 1(MCI)
        np1cog_subj = PD_subj["NP1COG"]  # 0 (HC), 1(Slight), 2(Mild), 3 (Moderate), 4(Severate)
        year_subj = PD_subj["YEAR"]
        