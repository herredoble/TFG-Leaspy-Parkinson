# -*- coding: utf-8 -*-
"""
Created on Mon Sep 11 12:25:15 2023

@author: rroca
"""

# In[50]:


import pandas as pd
import scipy.stats as stats
#import tabulate as tabulate
from tabulate import tabulate
import numpy as np
from scipy.stats import f_oneway, ttest_ind, chi2_contingency
from statsmodels.stats.multicomp import pairwise_tukeyhsd
import regex as re

#file_xlsx = './data/PPMI_Original_Cohort_BL_to_Year_5_Dataset_Apr2020.xlsx'
file_csv = './data/PPMI_Original_Cohort_BL_to_Year_5_Dataset_Apr2020_csv.csv'
#In [51]:
#df=pd.read_excel(file_xlsx)
df=pd.read_csv(file_csv)
#In [52]:

#NM subjects????    
data_nm={}
data_nm["Group"]=["Subjects","Age","Female","Educatión", "APOE4", "MOCA","GDS","UPSIT","REM","LNS","SDMT","JLO","INMEDIATE","HVLTRDLY","SFT","ADL","SCOPA","MEANPUT","MEANCAU", "ABETA", "ASYN", "TAU","PTAU", "pTauAB","UPDRSTOT","UPDRSTOTOM","UPDRS1","UPDRS2","UPDRS3","UPDRS3ON"]

df_PD=df[(df["APPRDX"]==1)] #SELECCIONA PD


#In [53]:
def Cognitive_groups(df):  
    
    ID=df["PATNO"].unique()
    cogstate = []
    MCI_testscores = []
    np1cog = []
    convertTimeCogstate = []
    convertTimeMCI_test = []
    convertTimeNp1cog = []
    ID_sinCog = []    
    
    for i in range(len(ID)):
        
        index = df[df["PATNO"] == ID[i]].index #indice visitas paciente
        PD_subj = df.iloc[index, :]  #dataframe visitas paciente
        
        cogstate_subj = PD_subj["cogstate"]  # 1(HC), 2(MCI), 3(Dementia)
        MCI_testscores_subj = PD_subj["MCI_testscores"]  # 0 (HC), 1(MCI)
        np1cog_subj = PD_subj["NP1COG"]  # 0 (HC), 1(Slight), 2(Mild), 3 (Moderate), 4(Severate)
        year_subj = PD_subj["YEAR"]
        
        year_cog = year_subj[~np.isnan(cogstate_subj)]
        cogstate_subj = cogstate_subj[~np.isnan(cogstate_subj)]
        
        if len(cogstate_subj)>0:
            # Obtener el último valor de cogstate
            cogstate.append(cogstate_subj.iloc[-1])
            
            if cogstate_subj.iloc[-1] > 1:
                convertTimeCogstate.append(np.min(year_cog[cogstate_subj > 1]))
            else:
                convertTimeCogstate.append(np.max(year_cog))
        else:
            ID_sinCog.append([1, ID[i]])
    
        MCI_testscores_subj = MCI_testscores_subj[~np.isnan(MCI_testscores_subj)]
        np1cog_subj = np1cog_subj[~np.isnan(np1cog_subj)]
       
        if len(MCI_testscores_subj) > 0:
            MCI_testscores.append(MCI_testscores_subj.iloc[-1])
           
            if MCI_testscores_subj.iloc[-1] > 0:
               convertTimeMCI_test.append(np.min(year_subj[MCI_testscores_subj > 0]))
            else:
                convertTimeMCI_test.append(np.max(year_subj))
        else:
            ID_sinCog.append([2, ID[i]])
       
        if len(np1cog_subj) > 0:
            np1cog.append(np1cog_subj.iloc[-1])
           
            if np1cog_subj.iloc[-1] > 0:
                convertTimeNp1cog.append(np.min(year_subj[np1cog_subj > 0]))
            else:
                convertTimeNp1cog.append(np.max(year_subj))
        else:
            ID_sinCog.append([3, ID[i]])
    
    # Convertir las listas en Series de Pandas y agregarlas al DataFrame df
    df["cogstate_end"] = pd.Series(cogstate)
    df["MCI_testscores_end"] = pd.Series(MCI_testscores)
    df["np1cog_end"] = pd.Series(np1cog)
    df["convertTimeCogstate"] = pd.Series(convertTimeCogstate)
    df["convertTimeMCI_test"] = pd.Series(convertTimeMCI_test)
    df["convertTimeNp1cog"] = pd.Series(convertTimeNp1cog)
            
    return df, ID_sinCog
        
    """
    cogstate = np.full((len(df), 1), np.nan)
    MCI_testscores = np.full((len(df), 1), np.nan)
    np1cog = np.full((len(df), 1), np.nan)
    convertTimeCogstate = np.full((len(df), 1), np.nan)
    convertTimeMCI_test = np.full((len(df), 1), np.nan)
    convertTimeNp1cog = np.full((len(df), 1), np.nan)
    ID_sinCog = []
        
        
        if len(cogstate_subj) > 0:
            if index >= 0 and index < len(cogstate_subj):
                cogstate[index] = cogstate_subj[-1]
                if cogstate_subj[-1] > 1:
                    convertTimeCogstate[index] = np.tile(np.min(year_cog[cogstate_subj > 1]), len(index))
                else:
                    convertTimeCogstate[index] = np.tile(np.max(year_cog), len(index))           
            else:
                print(f'ERROR')
        else:
            ID_sinCog = np.vstack((ID_sinCog, [1, ID[i]]))
        
    
        ## Criteria MCI_testscores:  0 (HC), 1(MCI)
        year_MCI = year_subj[~np.isnan(MCI_testscores_subj)]
        MCI_testscores_subj = MCI_testscores_subj[~np.isnan(MCI_testscores_subj)]
        
        if len(MCI_testscores_subj) > 0:
            MCI_testscores[index] = MCI_testscores_subj[-1]
            if MCI_testscores_subj[-1] > 0:
                convertTimeMCI_test[index] = np.tile(np.min(year_MCI[MCI_testscores_subj > 0]), len(index))
            else:
                convertTimeMCI_test[index] = np.tile(np.max(year_MCI), len(index))
        else:
            print(f'Subject {ID[i]} without MCI testscores data')
            ID_sinCog = np.vstack(ID_sinCog, [2, ID[i]])
            
            
            
        ## Criteria np1cog: 0 (HC), 1(Slight), 2(Mild), 3 (Moderate), 4(Severate)
        year_cog=year_subj[~np.isnan(np1cog_subj)]
        np1cog_subj=np1cog_subj[~np.isnan(np1cog_subj)]
        if len(np1cog_subj)>0:
            np1cog[index]=np1cog_subj[-1]
            if np1cog_subj[-1] > 1:        
                convertTimeNp1cog[index]=np.tile(np.min(year_cog[np1cog_subj>1]), len(index))
            else:
                convertTimeNp1cog[index]=np.tile(np.max(year_cog),len(index))          
        else:
            print(f'Subject {ID[i]} without np1cog data')
            ID_sinCog=np.vstack(ID_sinCog, [3, ID[i]])
            
    
    df["cogstate_end"] = cogstate
    df["MCI_testscores_end"] = MCI_testscores
    df["np1cog_end"] = np1cog
    
    df["convertTimeCogstate"] = convertTimeCogstate
    df["convertTimeMCI_test"] = convertTimeMCI_test
    df["convertTimeNp1cog"] = convertTimeNp1cog
    """
        
    
#In [54]:
def estimateCogState(df, ID_sinCog):
    ID_sinCog=ID_sinCog[:,1]
    for i in range(len(ID_sinCog)):
        index=df[df["PATNO"]==ID_sinCog[i]].index
        MCI_test = df.loc[index[0], "MCI_testscores_end"]
        MCI_test_ConvertTime=df.loc[index[0],"convertTimeMCI_test"]
        np1cog=df.loc[index[0],"np1cog_end"]
        np1cog_ConvertTime=df.loc[index[0],"convertTimeNp1cog"]
        if MCI_test>0 and np1cog>=1:
            df.iloc[index,"cogstate_end"]=2
            df.iloc[index,"onvertTimeCogstate"]=(MCI_test_ConvertTime + np1cog_ConvertTime)/2
        elif (MCI_test==0 and np1cog<2) or np1cog==0:
            df.iloc[index, "cogstate_end"]=1
            df.iloc[index, "convertTimeCogstate"]=(MCI_test_ConvertTime + np1cog_ConvertTime)/2
        else:
            print(f'Discrepance criteria between MCI-Test vs np1cog from {ID_sinCog[i]}')
            
    return df



#In [55]:
df, ID_sinCog = Cognitive_groups(df_PD)
df = estimateCogState(df, ID_sinCog)

for dx_category in ["PD_CU", "PD_MCI","PD_DEMENTIA"]:
    if dx_category=="PD_CU":
        filtered_df=df[df["cogstate_end"]==1]
    elif dx_category=="PD_MCI":
        filtered_df=df[df["cogstate_end"]==2]
    else:
        filtered_df=df[df["cogstate_end"]==3]
        
    #Second filtering at bl
    filtered_df=filtered_df[filtered_df["YEAR"]==0]
     
    #SUBJECTS
    filtered_subjects=filtered_df["PATNO"].nunique()
    subjects=df["PATNO"].nunique()
    filtered_subjects_percentage = f"{(filtered_subjects/subjects)*100:.1f}%"
    
    #FEMALE
    female_subjects = filtered_df[filtered_df["gen"] == 2]["PATNO"].nunique()
    female_percentage = f"{(female_subjects/filtered_subjects)*100:.1f}%"
    
    #APOE4
    APOE_e4_subjects = filtered_df[filtered_df["APOE_e4"] > 0]["PATNO"].nunique()
    APOE_e4_n = filtered_df[(filtered_df["APOE_e4"] >=0) & (filtered_df["APOE_e4"]<=2)]["PATNO"].nunique()
    APOE_e4_percentage = f"{(APOE_e4_subjects/APOE_e4_n)*100:.1f}%"
    
    #AGE
    age_mean = filtered_df["age"].mean()
    age_std = filtered_df["age"].std()
    age_min = filtered_df["age"].min()
    age_max = filtered_df["age"].max()
    age_stats = f"{age_mean:.1f} ({age_std:.1f}) ({age_min:.1f}, {age_max:.1f})"
    
    #EDUCATION
    education_mean = filtered_df["EDUCYRS"].mean()
    education_std = filtered_df["EDUCYRS"].std()
    education_min = filtered_df["EDUCYRS"].min()
    education_max = filtered_df["EDUCYRS"].max()
    education_stats = f"{education_mean:.1f} ({education_std:.1f}) ({education_min:.1f}, {education_max:.1f})"
        
    #COGNITIVE MARKERS (MOCA, GDS, UPSIT, REM, LNS, SDMT, JLO, INMEDIATE, HVLTRDLY, SFT, ADL, SCOPA)
    moca_mean = filtered_df["moca"].mean()
    moca_std = filtered_df["moca"].std()
    moca_min = filtered_df["moca"].min()
    moca_max = filtered_df["moca"].max()
    moca_stats = f"{moca_mean:.1f} ({moca_std:.1f}) ({moca_min:.1f}, {moca_max:.1f})"
    
    GDS_mean = filtered_df["gds"].mean()
    GDS_std = filtered_df["gds"].std()
    GDS_min = filtered_df["gds"].min()
    GDS_max = filtered_df["gds"].max()
    GDS_stats = f"{GDS_mean:.1f} ({GDS_std:.1f}) ({GDS_min:.1f}, {GDS_max:.1f})"
    
    UPSIT_mean = filtered_df["upsit"].mean()
    UPSIT_std = filtered_df["upsit"].std()
    UPSIT_min = filtered_df["upsit"].min()
    UPSIT_max = filtered_df["upsit"].max()
    UPSIT_stats = f"{UPSIT_mean:.1f} ({UPSIT_std:.1f}) ({UPSIT_min:.1f}, {UPSIT_max:.1f})"
   
    REM_mean = filtered_df["rem"].mean()
    REM_std = filtered_df["rem"].std()
    REM_min = filtered_df["rem"].min()
    REM_max = filtered_df["rem"].max()
    REM_stats = f"{REM_mean:.1f} ({REM_std:.1f}) ({REM_min:.1f}, {REM_max:.1f})"
   
    LNS_mean = filtered_df["lns"].mean()
    LNS_std = filtered_df["lns"].std()
    LNS_min = filtered_df["lns"].min()
    LNS_max = filtered_df["lns"].max()
    LNS_stats = f"{LNS_mean:.1f} ({LNS_std:.1f}) ({LNS_min:.1f}, {LNS_max:.1f})"
   
    SDMT_mean = filtered_df["SDMTOTAL"].mean()
    SDMT_std = filtered_df["SDMTOTAL"].std()
    SDMT_min = filtered_df["SDMTOTAL"].min()
    SDMT_max = filtered_df["SDMTOTAL"].max()
    SDMT_stats = f"{SDMT_mean:.1f} ({SDMT_std:.1f}) ({SDMT_min:.1f}, {SDMT_max:.1f})"
   
    JLO_mean = filtered_df["bjlot"].mean()
    JLO_std = filtered_df["bjlot"].std()
    JLO_min = filtered_df["bjlot"].min()
    JLO_max = filtered_df["bjlot"].max()
    JLO_stats = f"{JLO_mean:.1f} ({JLO_std:.1f}) ({JLO_min:.1f}, {JLO_max:.1f})"
     
    INMEDIATE_mean = filtered_df["hvlt_immediaterecall"].mean()
    INMEDIATE_std = filtered_df["hvlt_immediaterecall"].std()
    INMEDIATE_min = filtered_df["hvlt_immediaterecall"].min()
    INMEDIATE_max = filtered_df["hvlt_immediaterecall"].max()
    INMEDIATE_stats = f"{INMEDIATE_mean:.1f} ({INMEDIATE_std:.1f}) ({INMEDIATE_min:.1f}, {INMEDIATE_max:.1f})"
    
    HVLTRDLY_mean = filtered_df["HVLTRDLY"].mean()
    HVLTRDLY_std = filtered_df["HVLTRDLY"].std()
    HVLTRDLY_min = filtered_df["HVLTRDLY"].min()
    HVLTRDLY_max = filtered_df["HVLTRDLY"].max()
    HVLTRDLY_stats = f"{HVLTRDLY_mean:.1f} ({HVLTRDLY_std:.1f}) ({HVLTRDLY_min:.1f}, {HVLTRDLY_max:.1f})"
     
    SFT_mean = filtered_df["sft"].mean()
    SFT_std = filtered_df["sft"].std()
    SFT_min = filtered_df["sft"].min()
    SFT_max = filtered_df["sft"].max()
    SFT_stats = f"{SFT_mean:.1f} ({SFT_std:.1f}) ({SFT_min:.1f}, {SFT_max:.1f})"
     
    ADL_mean = filtered_df["MSEADLG"].mean()
    ADL_std = filtered_df["MSEADLG"].std()
    ADL_min = filtered_df["MSEADLG"].min()
    ADL_max = filtered_df["MSEADLG"].max()
    ADL_stats = f"{ADL_mean:.1f} ({ADL_std:.1f}) ({ADL_min:.1f}, {ADL_max:.1f})"
     
    SCOPA_mean = filtered_df["scopa"].mean()
    SCOPA_std = filtered_df["scopa"].std()
    SCOPA_min = filtered_df["scopa"].min()
    SCOPA_max = filtered_df["scopa"].max()
    SCOPA_stats = f"{SCOPA_mean:.1f} ({SCOPA_std:.1f}) ({SCOPA_min:.1f}, {SCOPA_max:.1f})"
     
     
    # DAT imaging (MEANPUT, MEANCAU)
    MEANPUT_mean = filtered_df["mean_putamen"].mean()
    MEANPUT_std = filtered_df["mean_putamen"].std()
    MEANPUT_min = filtered_df["mean_putamen"].min()
    MEANPUT_max = filtered_df["mean_putamen"].max()
    MEANPUT_stats = f"{MEANPUT_mean:.1f} ({MEANPUT_std:.1f}) ({MEANPUT_min:.1f}, {MEANPUT_max:.1f})"

    MEANCAU_mean = filtered_df["mean_caudate"].mean()
    MEANCAU_std = filtered_df["mean_caudate"].std()
    MEANCAU_min = filtered_df["mean_caudate"].min()
    MEANCAU_max = filtered_df["mean_caudate"].max()
    MEANCAU_stats = f"{MEANCAU_mean:.1f} ({MEANCAU_std:.1f}) ({MEANCAU_min:.1f}, {MEANCAU_max:.1f})"
    
     
    # CSF (ABETA, ASYN, TAU, PTAU, pTauAB)
    ABETA_mean = filtered_df["abeta"].mean()
    ABETA_std = filtered_df["abeta"].std()
    ABETA_min = filtered_df["abeta"].min()
    ABETA_max = filtered_df["abeta"].max()
    ABETA_stats = f"{ABETA_mean:.1f} ({ABETA_std:.1f}) ({ABETA_min:.1f}, {ABETA_max:.1f})"

    ASYN_mean = filtered_df["asyn"].mean()
    ASYN_std = filtered_df["asyn"].std()
    ASYN_min = filtered_df["asyn"].min()
    ASYN_max = filtered_df["asyn"].max()
    ASYN_stats = f"{ASYN_mean:.1f} ({ASYN_std:.1f}) ({ASYN_min:.1f}, {ASYN_max:.1f})"
     
    TAU_mean = filtered_df["tau"].mean()
    TAU_std = filtered_df["tau"].std()
    TAU_min = filtered_df["tau"].min()
    TAU_max = filtered_df["tau"].max()
    TAU_stats = f"{TAU_mean:.1f} ({TAU_std:.1f}) ({TAU_min:.1f}, {TAU_max:.1f})"

    PTAU_mean = filtered_df["ptau"].mean()
    PTAU_std = filtered_df["ptau"].std()
    PTAU_min = filtered_df["ptau"].min()
    PTAU_max = filtered_df["ptau"].max()
    PTAU_stats = f"{PTAU_mean:.1f} ({PTAU_std:.1f}) ({PTAU_min:.1f}, {PTAU_max:.1f})"
     
    pTauAB_mean = filtered_df["ptau_ab"].mean()
    pTauAB_std = filtered_df["ptau_ab"].std()
    pTauAB_min = filtered_df["ptau_ab"].min()
    pTauAB_max = filtered_df["ptau_ab"].max()
    pTauAB_stats = f"{pTauAB_mean:.1f} ({pTauAB_std:.1f}) ({pTauAB_min:.1f}, {pTauAB_max:.1f})"


    # MOTOR (UPDRSTOT, UPDRSTOTON, UPDRS1, UPDRS2, UPDRS3, UPDRS3ON)
    UPDRSTOT_mean = filtered_df["updrs_totscore"].mean()
    UPDRSTOT_std = filtered_df["updrs_totscore"].std()
    UPDRSTOT_min = filtered_df["updrs_totscore"].min()
    UPDRSTOT_max = filtered_df["updrs_totscore"].max()
    UPDRSTOT_stats = f"{UPDRSTOT_mean:.1f} ({UPDRSTOT_std:.1f}) ({UPDRSTOT_min:.1f}, {UPDRSTOT_max:.1f})"

    UPDRSTOTON_mean = filtered_df["updrs_totscore_on"].mean()
    UPDRSTOTON_std = filtered_df["updrs_totscore_on"].std()
    UPDRSTOTON_min = filtered_df["updrs_totscore_on"].min()
    UPDRSTOTON_max = filtered_df["updrs_totscore_on"].max()
    UPDRSTOTON_stats = f"{UPDRSTOTON_mean:.1f} ({UPDRSTOTON_std:.1f}) ({UPDRSTOTON_min:.1f}, {UPDRSTOTON_max:.1f})"

    UPDRS1_mean = filtered_df["updrs1_score"].mean()
    UPDRS1_std = filtered_df["updrs1_score"].std()
    UPDRS1_min = filtered_df["updrs1_score"].min()
    UPDRS1_max = filtered_df["updrs1_score"].max()
    UPDRS1_stats = f"{UPDRS1_mean:.1f} ({UPDRS1_std:.1f}) ({UPDRS1_min:.1f}, {UPDRS1_max:.1f})"
     
    UPDRS2_mean = filtered_df["updrs2_score"].mean()
    UPDRS2_std = filtered_df["updrs2_score"].std()
    UPDRS2_min = filtered_df["updrs2_score"].min()
    UPDRS2_max = filtered_df["updrs2_score"].max()
    UPDRS2_stats = f"{UPDRS2_mean:.1f} ({UPDRS2_std:.1f}) ({UPDRS2_min:.1f}, {UPDRS2_max:.1f})"

    UPDRS3_mean = filtered_df["updrs3_score"].mean()
    UPDRS3_std = filtered_df["updrs3_score"].std()
    UPDRS3_min = filtered_df["updrs3_score"].min()
    UPDRS3_max = filtered_df["updrs3_score"].max()
    UPDRS3_stats = f"{UPDRS3_mean:.1f} ({UPDRS3_std:.1f}) ({UPDRS3_min:.1f}, {UPDRS3_max:.1f})"
     
    UPDRS3ON_mean = filtered_df["updrs3_score_on"].mean()
    UPDRS3ON_std = filtered_df["updrs3_score_on"].std()
    UPDRS3ON_min = filtered_df["updrs3_score_on"].min()
    UPDRS3ON_max = filtered_df["updrs3_score_on"].max()
    UPDRS3ON_stats = f"{UPDRS3ON_mean:.1f} ({UPDRS3ON_std:.1f}) ({UPDRS3ON_min:.1f}, {UPDRS3ON_max:.1f})"
     
    data_nm[dx_category]=[f"{filtered_subjects} ({filtered_subjects_percentage})", f"{female_subjects} ({female_percentage})", f"{APOE_e4_subjects} (n={APOE_e4_n} {APOE_e4_percentage})", age_stats, education_stats, GDS_stats, UPSIT_stats, REM_stats, UPDRS3_stats, UPDRSTOT_stats, UPDRSTOTON_stats, UPDRS1_stats, UPDRS2_stats,  UPDRS3ON_stats, moca_stats, LNS_stats, SDMT_stats, JLO_stats, INMEDIATE_stats, HVLTRDLY_stats, SFT_stats, ADL_stats, SCOPA_stats, ABETA_stats, ASYN_stats, TAU_stats, PTAU_stats, pTauAB_stats, MEANPUT_stats, MEANCAU_stats]
     

# In[56]:


#Group1 : PD_CU, Group2 : PD_MCI, Group3 : PD_DEMENTIA
#PD_CU to PD_MCI (a)
#PD_CU  to PD_DEMENTIA (b)
#PD_MCI to PD_DEMENTIA (c)

def one_way_anova_with_posthoc(group1, group2, group3):
    # Perform one-way ANOVA
    f_value, p_value = f_oneway(group1, group2, group3)
    print(p_value)
    # Check if p-value is less than 0.01
    if p_value < 0.01:
        # Perform Tukey post hoc test
        data = np.concatenate([group1, group2, group3])
        labels = ['group1'] * len(group1) + ['group2'] * len(group2)+['group3'] * len(group3)
        tukey_results = pairwise_tukeyhsd(data, labels, 0.01)
        possible_results = ['a','b','c','d','e','f']
        post_hoc = [res for res,reject in zip(possible_results,tukey_results.reject) if reject == True]
        post_hoc = ",".join(post_hoc)
        return post_hoc


# In[57]:


#Group1 : PD_CU, Group2 : PD_MCI, Group3 : PD_DEMENTIA
#PD_CU to PD_MCI (a)
#PD_CU  to PD_DEMENTIA (b)
#PD_MCI to PD_DEMENTIA (c)
 
def chi_square_with_posthoc(group1, group2, group3, contingency_table):
    # Perform chi-square test
    chi2, p, dof, expected = chi2_contingency(contingency_table)

    # Perform post-hoc test if p-value is significant
    if p < 0.01:
        data = np.concatenate([group1, group2, group3])
        labels = ['group1'] * len(group1) + ['group2'] * len(group2)+ ['group3'] * len(group3)
        tukey_results = pairwise_tukeyhsd(data, labels, 0.01)
        possible_results = ['a','b','c','d','e','f']
        post_hoc = [res for res,reject in zip(possible_results,tukey_results.reject) if reject == True]
        post_hoc = ",".join(post_hoc)
        return post_hoc


# In[58]:

filtered_nm_PD_CU=df[df["cogstate_end"]==1 & df["YEAR"]==0]
filtered_nm_PD_MCI=df[df["cogstate_end"]==2 & df["YEAR"]==0]
filtered_nm_PD_DEMENTIA=df[df["cogstate_end"]==3 & df["YEAR"]==0]

data_nm["Post-Hoc"] = [""]*len(data_nm["Group"])

# In[59]:

group1_nm = filtered_nm_PD_CU["gen"].dropna()
group2_nm = filtered_nm_PD_MCI["gen"].dropna()
group3_nm = filtered_nm_PD_DEMENTIA["gen"].dropna()

# Convert data to contingency table format
contingency_table_nm = np.array([
    [np.sum(group1_nm == 2), np.sum(group1_nm == 1)],
    [np.sum(group2_nm == 2), np.sum(group2_nm == 1)],
    [np.sum(group3_nm == 2), np.sum(group3_nm == 1)]
])

data_nm["Post-Hoc"][data_nm["Group"].index("Female")] = chi_square_with_posthoc(group1_nm, group2_nm, group3_nm, contingency_table_nm)

# In[60]:


#APOE4
group1_nm = filtered_nm_PD_CU["APOE_e4"].dropna()
group2_nm = filtered_nm_PD_MCI["APOE_e4"].dropna()
group3_nm = filtered_nm_PD_DEMENTIA["APOE_e4"].dropna()


# Convert data to contingency table format
contingency_table_nm = np.array([
    [np.sum(group1_nm == 0), np.sum(group1_nm == 1), np.sum(group1_nm == 2)],
    [np.sum(group2_nm == 0), np.sum(group2_nm == 1), np.sum(group1_nm == 2)],
    [np.sum(group3_nm == 0), np.sum(group3_nm == 1), np.sum(group3_nm == 2)]
])

data_nm["Post-Hoc"][data_nm["Group"].index("APOE4")] = chi_square_with_posthoc(group1_nm, group2_nm, group3_nm, contingency_table_nm)


# In[61]:
     
# data_nm["Group"]=["Subjects","Female","APOE4","Age","Education", "GDS","UPSIT","REM","UPDRS3", "UPDRSTOT","UPDRSTOTOM","UPDRS1","UPDRS2","UPDRS3ON","MOCA","LNS","SDMT","JLO","INMEDIATE","HVLTRDLY","SFT","ADL","SCOPA", "ABETA", "ASYN", "TAU","PTAU", "pTauAB",  "MEANPUT","MEANCAU"]
variables = ["age", "EDUCYRS", "gds", "upsit", "rem", "updrs3_score", "updrs_totscore","updrs_totscore_on", "updrs1_score", "updrs2_score", "updrs3_score_on", "moca","lns","SDMTOTAL","bjlot","hvlt_immediaterecall","HVLTRDLY","sft","MSEADLG","scopa","abeta","asyn","tau","ptau","ptau_ab","mean_putamen","mean_caudate"]
     
for i, v in enumerate(variables):
    group1_nm = filtered_nm_PD_CU[v].dropna()
    group2_nm = filtered_nm_PD_MCI[v].dropna()
    group3_nm = filtered_nm_PD_DEMENTIA[v].dropna()

    data_nm["Post-Hoc"][i+3] = one_way_anova_with_posthoc(group1_nm, group2_nm, group3_nm)


# In[62]:

#Display table (and latex format)
table_nm = pd.DataFrame(data_nm)
latex_table = table_nm.to_latex(index=False)
print(latex_table)
table_nm = table_nm.style.hide(axis="index")
#display(table_nm)
        
    
    
    
    
    
###IMPORTANTE PARA MAS ADELANTE
    
    #In [53]:
    """
    def convert_visit_date_PPMI(visit_date):
        n_visit = len(visit_date)
        month_str = [visit_date[i][:3] for i in range(n_visit)]
        
        month_dict = {
            'JAN': 1, 'FEB': 2, 'MAR': 3, 'APR': 4, 'MAY': 5, 'JUN': 6,
            'JUL': 7, 'AUG': 8, 'SEP': 9, 'OCT': 10, 'NOV': 11, 'DEC': 12
        }
        
        month = [month_dict.get(m, -1) for m in month_str]
        year = [int(visit_date[i][3:]) for i in range(n_visit)]
        
        # Construct date array
        date = [datetime(year[i], month[i], 1) for i in range(n_visit)]
        
        return date


    #In [54]:
    def getOnsetTime_PPMI(ID, date, convert, convertTime, YEAR):
        onset = np.full(len(ID), np.nan)
        
        # Convert
        RID = np.unique(ID[convert == 1])
        for i in range(len(RID)):
            index = np.where(ID == RID[i])[0]
            convertTime_year = convertTime[index[0]]
            years = YEAR[index]
            idx = np.where(years == convertTime_year)[0][0]
            time_zero = date[index[idx]]
            try:
                Delta_days = (date[index[idx]] - date[index[idx - 1]]).days / 2
                onset[index] = ((date[index] - time_zero).days + Delta_days) / 30.4167 / 12
            except:
                onset[index] = (date[index] - date[index[0]]).days / 30.4167 / 12

        RID = np.unique(ID[convert == 0])
        for i in range(len(RID)):
            index = np.where(ID == RID[i])[0]
            time_zero = date[index[-1]]
            onset[index] = (date[index] - time_zero).days / 30.4167 / 12

        return onset
    """
    
    
    
    
    
    
    
    
    
    
    